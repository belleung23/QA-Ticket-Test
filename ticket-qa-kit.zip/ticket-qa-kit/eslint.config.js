// Flat config (ESLint 9). The Playwright plugin rules are the important part:
// they fail a spec that has no assertion, a conditional assertion or a fixed sleep.
import js from "@eslint/js";
import tseslint from "typescript-eslint";

const optional = async (name) => {
  try {
    return (await import(name)).default;
  } catch {
    console.warn(`eslint: ${name} is not installed — run \`npm install\` to enable its rules`);
    return undefined;
  }
};
const playwright = await optional("eslint-plugin-playwright");

export default tseslint.config(
  { ignores: ["dist/**", "node_modules/**", "test-results/**", "playwright-report/**", ".auth/**"] },
  js.configs.recommended,
  ...tseslint.configs.recommended,
  ...(playwright
    ? [
        {
          files: ["tests/**/*.ts"],
          ...playwright.configs["flat/recommended"],
          rules: {
            ...playwright.configs["flat/recommended"].rules,
            "playwright/expect-expect": "error",
            "playwright/no-conditional-expect": "error",
            "playwright/no-skipped-test": "warn",
            "playwright/no-wait-for-timeout": "error",
            "playwright/no-useless-not": "error",
            "playwright/no-focused-test": "error",
          },
        },
      ]
    : []),
  {
    rules: {
      "@typescript-eslint/no-unused-vars": ["error", { argsIgnorePattern: "^_" }],
      "@typescript-eslint/no-explicit-any": "error",
    },
  },
);
