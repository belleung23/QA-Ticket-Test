# QA Report — <TICKET>: <title>

| | |
|---|---|
| **Verdict** | **PASSED / FAILED / INCOMPLETE** |
| Project | <project.name> |
| Ticket | [<TICKET>](<url>) |
| Environment | `<env>` — <baseUrl> |
| Mode | Manual (agent-driven browser) / Automation (Playwright) |
| Tester | <human name> |
| Date | YYYY-MM-DD |

## Execution summary

- Total / Pass / Fail / Blocked / Skipped / Not run

## AC coverage

| AC | Requirement | Test cases | Result |
|---|---|---|---|

## Test cases

(the manual.md table, filled)

## Failures

### #n — <description>
**Expected:** … **Actual:** … **Evidence:** …
**Steps to reproduce** 1. … 2. …
**Likely cause:** …

## Bugs filed

## Notes

- session recoveries, flaky observations, environment problems, `test.fixme` markers
