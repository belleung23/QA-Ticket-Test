# <TICKET> — Manual Test Cases

Ticket: <url>  
Environment: `<env key>` — <baseUrl>  
Analysis: ./analysis.md

## Preconditions / test data

- <role / account needed, feature flags, seed data>

> Status vocabulary: Pass | Fail | Blocked | Skipped | — (not run).  
> Automate = yes marks a case approved for conversion to Playwright (`tqa scaffold`).  
> Column order is a contract — do not rename or reorder.

| # | AC | Priority | Type | Test Description | Test Steps | Expected Result | Actual Result | Status | Evidence | Automate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | AC1 | High | Happy Path | <what this case proves> | 1. Open `/route` as <role><br>2. Click … <br>3. … | <observable outcome: text, URL, list contents after reload> | — | — | — | — |
| 2 | AC1 | Medium | Negative | <refusal behaviour> | 1. …<br>2. Submit with <invalid input> | <exact error text / disabled control / 4xx> | — | — | — | — |
| 3 | AC2 | Low | Edge Case | <boundary> | 1. … | … | — | — | — | — |
