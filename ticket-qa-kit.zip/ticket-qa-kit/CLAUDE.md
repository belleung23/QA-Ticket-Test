# CLAUDE.md

Read `AGENTS.md` — it is the shared contract for every agent in this repo.

Skills under `.claude/skills/` are the procedures. Entry point for a ticket: `qa-ticket-pipeline`.
Always read `qa-shared-rules` before any other QA skill. Configuration comes from
`qa.config.yaml` + `.env` only (`npm run tqa -- config`); never hardcode a URL, account or token.
Automation is derived from executed manual test cases, never written straight from the ticket.
No AI attribution lines on commits or PRs.
