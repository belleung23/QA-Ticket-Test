import { defineConfig, devices } from "@playwright/test";
import { loadConfig, resolveEnvironment } from "./src/config/load.js";

// Everything here is read from qa.config.yaml + .env — no URLs, accounts or
// paths are hardcoded. Change the project, not this file.
const cfg = loadConfig();
const { key: envKey, env } = resolveEnvironment(cfg);
const headless = process.env.HEADED === "true" ? false : cfg.playwright.headless;
const deviceByBrowser = { chromium: devices["Desktop Chrome"], firefox: devices["Desktop Firefox"], webkit: devices["Desktop Safari"] } as const;

export default defineConfig({
  testDir: cfg.paths.specs,
  testMatch: /.*\.spec\.ts$/,
  globalSetup: "./src/auth/global-setup.ts",
  timeout: cfg.playwright.timeoutMs,
  expect: { timeout: Math.min(cfg.playwright.timeoutMs, 10_000) },
  retries: process.env.CI ? cfg.playwright.retries : 0,
  workers: process.env.CI ? cfg.playwright.workers : undefined,
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  reporter: [["list"], ["html", { open: "never" }], ["json", { outputFile: "test-results/results.json" }]],
  outputDir: "test-results",
  metadata: { project: cfg.project.name, environment: envKey, baseUrl: env.baseUrl },
  use: {
    baseURL: env.baseUrl,
    headless,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
    actionTimeout: cfg.playwright.timeoutMs,
    navigationTimeout: cfg.playwright.timeoutMs,
  },
  projects: [{ name: cfg.playwright.browser, use: { ...deviceByBrowser[cfg.playwright.browser] } }],
});
