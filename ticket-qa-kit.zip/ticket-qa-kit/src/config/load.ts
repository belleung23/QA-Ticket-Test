import fs from "node:fs";
import path from "node:path";
import { config as loadDotenv } from "dotenv";
import YAML from "yaml";
import { configSchema, type EnvironmentConfig, type QaConfig } from "./schema.js";

const CONFIG_FILE = "qa.config.yaml";

/** Replace ${VAR} and ${VAR:-default} with values from process.env. Unset → "". */
export function interpolateEnv(value: string, env: NodeJS.ProcessEnv = process.env): string {
  return value.replace(/\$\{([A-Z0-9_]+)(?::-([^}]*))?\}/gi, (_m, name: string, fallback?: string) => {
    const v = env[name];
    return v !== undefined && v !== "" ? v : (fallback ?? "");
  });
}

function interpolateDeep<T>(node: T, env: NodeJS.ProcessEnv): T {
  if (typeof node === "string") return interpolateEnv(node, env) as unknown as T;
  if (Array.isArray(node)) return node.map((n) => interpolateDeep(n, env)) as unknown as T;
  if (node && typeof node === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(node as Record<string, unknown>)) out[k] = interpolateDeep(v, env);
    return out as T;
  }
  return node;
}

function dropEmptyStrings<T>(node: T): T {
  if (Array.isArray(node)) return node.map(dropEmptyStrings) as unknown as T;
  if (node && typeof node === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(node as Record<string, unknown>)) {
      if (v === "") continue;
      out[k] = dropEmptyStrings(v);
    }
    return out as T;
  }
  return node;
}

export function findRepoRoot(start = process.cwd()): string {
  let dir = start;
  for (let i = 0; i < 10; i++) {
    if (fs.existsSync(path.join(dir, CONFIG_FILE)) || fs.existsSync(path.join(dir, "qa.config.example.yaml"))) return dir;
    const parent = path.dirname(dir);
    if (parent === dir) break;
    dir = parent;
  }
  return start;
}

export function loadConfig(opts: { root?: string; file?: string } = {}): QaConfig {
  const root = opts.root ?? findRepoRoot();
  loadDotenv({ path: path.join(root, ".env"), override: false });
  const file = opts.file ?? path.join(root, CONFIG_FILE);
  if (!fs.existsSync(file)) {
    throw new Error(
      `No ${CONFIG_FILE} found in ${root}. Copy qa.config.example.yaml to ${CONFIG_FILE} and fill in your project.`,
    );
  }
  const raw = YAML.parse(fs.readFileSync(file, "utf8"));
  // An unset ${VAR} becomes "" — drop those keys so schema defaults apply instead of failing validation.
  const interpolated = dropEmptyStrings(interpolateDeep(raw, process.env));
  const parsed = configSchema.safeParse(interpolated);
  if (!parsed.success) {
    const issues = parsed.error.issues.map((i) => `  - ${i.path.join(".") || "(root)"}: ${i.message}`).join("\n");
    throw new Error(`${CONFIG_FILE} is invalid:\n${issues}`);
  }
  const cfg = parsed.data;
  if (!cfg.environments[cfg.defaultEnvironment]) {
    throw new Error(`defaultEnvironment "${cfg.defaultEnvironment}" is not one of: ${Object.keys(cfg.environments).join(", ")}`);
  }
  return cfg;
}

/**
 * Resolve which environment to use, in priority order:
 * explicit --env → QA_ENV → ticket-title hint ("[Prod]") → defaultEnvironment.
 * APP_BASE_URL (env) overrides the chosen environment's baseUrl.
 */
export function resolveEnvironment(
  cfg: QaConfig,
  opts: { env?: string; ticketTitle?: string } = {},
): { key: string; env: EnvironmentConfig } {
  const pick = (key: string) => {
    const env = cfg.environments[key];
    if (!env) throw new Error(`Unknown environment "${key}". Allowed: ${Object.keys(cfg.environments).join(", ")}`);
    const baseUrl = process.env.APP_BASE_URL?.trim() || env.baseUrl;
    return { key, env: { ...env, baseUrl } };
  };
  if (opts.env) return pick(opts.env.toLowerCase());
  if (process.env.QA_ENV) return pick(process.env.QA_ENV.toLowerCase());
  if (opts.ticketTitle) {
    const title = opts.ticketTitle.toLowerCase();
    for (const [key, hints] of Object.entries(cfg.environmentHints)) {
      if (hints.some((h) => title.includes(h.toLowerCase()))) return pick(key);
    }
  }
  return pick(cfg.defaultEnvironment);
}

export function storageStatePath(cfg: QaConfig, envKey: string, root = findRepoRoot()): string {
  return path.join(root, cfg.auth.storageStateDir, `${envKey}.storage-state.json`);
}

export type { QaConfig, EnvironmentConfig };
