import { z } from "zod";

const envSchema = z.object({
  baseUrl: z.string().url(),
  readOnly: z.boolean().default(false),
  /** Optional per-environment auth override (same shape as top-level auth.strategy). */
  authStrategy: z.enum(["none", "form", "storage-state", "script"]).optional(),
});

export const configSchema = z.object({
  project: z.object({
    name: z.string().min(1),
    ticketPattern: z.string().default("^[A-Z][A-Z0-9]+-\\d+$"),
  }),
  tracker: z.object({
    kind: z.enum(["linear", "jira"]),
    linear: z
      .object({
        apiKey: z.string().default(""),
        states: z
          .object({
            inQa: z.string().optional(),
            readyToRelease: z.string().optional(),
            failedQa: z.string().optional(),
          })
          .prefault({}),
      })
      .prefault({}),
    jira: z
      .object({
        baseUrl: z.string().default(""),
        email: z.string().default(""),
        apiToken: z.string().default(""),
        auth: z.enum(["basic", "bearer"]).default("basic"),
        acceptanceCriteriaField: z.string().default(""),
        transitions: z
          .object({
            readyToRelease: z.string().optional(),
            failedQa: z.string().optional(),
          })
          .prefault({}),
      })
      .prefault({}),
  }),
  environments: z.record(z.string(), envSchema).refine((r) => Object.keys(r).length > 0, {
    message: "at least one environment is required",
  }),
  defaultEnvironment: z.string(),
  environmentHints: z.record(z.string(), z.array(z.string())).prefault({}),
  auth: z.object({
    strategy: z.enum(["none", "form", "storage-state", "script"]).default("storage-state"),
    storageStateDir: z.string().default(".auth"),
    form: z
      .object({
        loginPath: z.string().default("/login"),
        usernameSelector: z.string(),
        passwordSelector: z.string(),
        submitSelector: z.string(),
        username: z.string().default(""),
        password: z.string().default(""),
        loggedInSelector: z.string().optional(),
      })
      .optional(),
    script: z.object({ path: z.string() }).optional(),
  }),
  paths: z
    .object({
      testCases: z.string().default("test-cases"),
      reports: z.string().default("test-reports"),
      specs: z.string().default("tests"),
      media: z.string().default("test-reports/media"),
    })
    .prefault({}),
  analysis: z
    .object({
      requirementHeadings: z.array(z.string()).default(["acceptance criteria", "^ac$", "requirements?"]),
      vagueWords: z.array(z.string()).default(["properly", "correctly", "as expected", "should work", "etc"]),
      riskAreas: z.array(z.string()).default([]),
    })
    .prefault({}),
  ui: z
    .object({
      port: z.number().int().positive().default(4321),
      /**
       * How the UI's "Run with agent" button starts an agent, with {prompt} replaced
       * by the slash command. Empty → the UI shows the command for you to paste.
       * e.g. claude -p "{prompt}"   or   codex exec "{prompt}"
       */
      agentCommand: z.string().default(""),
    })
    .prefault({}),
  playwright: z
    .object({
      browser: z.enum(["chromium", "firefox", "webkit"]).default("chromium"),
      headless: z.boolean().default(true),
      timeoutMs: z.number().int().positive().default(30000),
      retries: z.number().int().min(0).default(1),
      workers: z.number().int().positive().default(2),
      tagPrefix: z.string().default("@"),
    })
    .prefault({}),
});

export type QaConfig = z.infer<typeof configSchema>;
export type EnvironmentConfig = z.infer<typeof envSchema>;
