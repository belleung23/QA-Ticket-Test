#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import readline from "node:readline";
import { spawnSync } from "node:child_process";
import { Command } from "commander";
import { chromium, firefox, webkit } from "@playwright/test";
import { findRepoRoot, loadConfig, resolveEnvironment } from "./config/load.js";
import { makeAuthContext, saveStorageState } from "./auth/strategies.js";
import { Kit } from "./pipeline.js";
import { startUi } from "./ui/server.js";

const program = new Command();
program.name("tqa").description("ticket-qa-kit — ticket → requirements → manual test → Playwright automation, for any project").version("0.2.0");
const root = findRepoRoot();

program
  .command("init")
  .description("Create qa.config.yaml and .env from the examples (does not overwrite)")
  .action(() => {
    for (const [from, to] of [["qa.config.example.yaml", "qa.config.yaml"], [".env.example", ".env"]]) {
      const dst = path.join(root, to);
      if (fs.existsSync(dst)) console.log(`${to} already exists — skipped`);
      else {
        fs.copyFileSync(path.join(root, from), dst);
        console.log(`created ${to} — edit it for your project`);
      }
    }
  });

program
  .command("config")
  .description("Validate qa.config.yaml and show the resolved (secret-free) settings")
  .option("--env <key>")
  .action((o: { env?: string }) => {
    const cfg = loadConfig();
    const { key, env } = resolveEnvironment(cfg, { env: o.env });
    const mask = (s: string) => (s ? `${s.slice(0, 4)}…(${s.length} chars)` : "(empty)");
    console.log(
      JSON.stringify(
        {
          project: cfg.project,
          tracker: { kind: cfg.tracker.kind, linear: { apiKey: mask(cfg.tracker.linear.apiKey) }, jira: { baseUrl: cfg.tracker.jira.baseUrl, email: cfg.tracker.jira.email, apiToken: mask(cfg.tracker.jira.apiToken), auth: cfg.tracker.jira.auth } },
          environment: { key, ...env },
          auth: { strategy: env.authStrategy ?? cfg.auth.strategy, storageStateDir: cfg.auth.storageStateDir },
          paths: cfg.paths,
          ui: cfg.ui,
          playwright: cfg.playwright,
        },
        null,
        2,
      ),
    );
  });

program
  .command("ui")
  .description("Open the local web UI (ticket → analysis → test cases → record/run → report → spec)")
  .option("--port <n>")
  .action((o: { port?: string }) => {
    startUi({ port: o.port ? Number(o.port) : undefined });
  });

program
  .command("fetch <ticket>")
  .description("Fetch a ticket and save test-cases/<KEY>/ticket.json + ticket.md")
  .option("--json", "print JSON to stdout as well")
  .action(async (ticket: string, o: { json?: boolean }) => {
    const kit = new Kit(root);
    const t = await kit.fetch(ticket);
    if (o.json) console.log(JSON.stringify(t, null, 2));
    else console.log(`wrote ${kit.rel(kit.ticketDir(t.key))}/ticket.{json,md}`);
  });

program
  .command("analyze <ticket>")
  .description("Extract normalized acceptance criteria + clarifications → analysis.md, and scaffold manual.md if missing")
  .option("--env <key>")
  .action(async (ticket: string, o: { env?: string }) => {
    const kit = new Kit(root);
    const r = await kit.analyze(ticket, { env: o.env });
    for (const f of r.files) console.log(`wrote ${f}`);
    if (!r.manualCreated) console.log("manual.md exists — left untouched");
    console.log(`\n${r.analysis.requirements.length} requirement(s), ${r.analysis.clarifications.length} clarification(s).`);
  });

program
  .command("scaffold <ticket>")
  .description("Generate a Playwright spec from manual.md rows marked Automate = yes (recorded cases get real locators)")
  .option("--force", "overwrite an existing spec")
  .action((ticket: string, o: { force?: boolean }) => {
    const r = new Kit(root).scaffold(ticket, { force: o.force });
    for (const w of r.warnings) console.warn(`warning: ${w}`);
    console.log(`wrote ${r.file} — ${r.count} test(s). Replace every TODO with a falsifiable assertion, then: npm run tqa -- run ${ticket.toUpperCase()}`);
  });

program
  .command("report <ticket>")
  .description("Build test-reports/<KEY>_<VERDICT>_<date>.md and the ticket comment from manual.md")
  .requiredOption("--tester <name>", "person who ran the tests")
  .option("--env <key>")
  .option("--mode <mode>", "manual | automation", "manual")
  .option("--note <text...>")
  .action((ticket: string, o: { tester: string; env?: string; mode: "manual" | "automation"; note?: string[] }) => {
    const r = new Kit(root).report(ticket, { tester: o.tester, env: o.env, mode: o.mode, notes: o.note });
    console.log(`wrote ${r.reportFile}\nwrote ${r.commentFile}\nverdict: ${r.summary.verdict} (${r.summary.pass}/${r.summary.total} pass, ${r.summary.fail} fail, ${r.summary.blocked} blocked)`);
  });

program
  .command("comment <ticket>")
  .description("Post test-cases/<KEY>/comment.md (or --file) to the ticket")
  .option("--file <path>")
  .action(async (ticket: string, o: { file?: string }) => {
    const body = o.file ? fs.readFileSync(path.resolve(o.file), "utf8") : undefined;
    const r = await new Kit(root).comment(ticket, body);
    console.log(`comment posted: ${r.url ?? r.id}`);
  });

program
  .command("status <ticket> [name]")
  .description("List available states/transitions, or move the ticket to <name>")
  .action(async (ticket: string, name?: string) => {
    const kit = new Kit(root);
    if (!name) return console.log((await kit.listStatuses(ticket)).join("\n"));
    await kit.setStatus(ticket, name);
    console.log(`${ticket.toUpperCase()} → ${name}`);
  });

program
  .command("auth:save")
  .description("Open a headed browser, log in by hand (SSO/MFA ok), press Enter, and the session is saved for reuse")
  .option("--env <key>")
  .action(async (o: { env?: string }) => {
    const cfg = loadConfig();
    const { key, env } = resolveEnvironment(cfg, { env: o.env });
    const launcher = { chromium, firefox, webkit }[cfg.playwright.browser];
    const browser = await launcher.launch({ headless: false });
    const context = await browser.newContext({ baseURL: env.baseUrl });
    const page = await context.newPage();
    await page.goto(env.baseUrl);
    console.log(`\nLog in to ${env.baseUrl} in the browser window. When you are on a logged-in page, come back here and press Enter.`);
    await new Promise<void>((resolve) => readline.createInterface({ input: process.stdin, output: process.stdout }).question("", () => resolve()));
    const file = await saveStorageState(context, makeAuthContext(cfg, key, env));
    await browser.close();
    console.log(`saved session → ${path.relative(root, file)} (git-ignored). Re-run when it expires.`);
  });

program
  .command("run <ticket>")
  .description("Run the Playwright specs for a ticket on the chosen environment")
  .option("--env <key>")
  .option("--headed")
  .allowUnknownOption()
  .action((ticket: string, o: { env?: string; headed?: boolean }, cmd: Command) => {
    const cfg = loadConfig();
    const { key: envKey } = resolveEnvironment(cfg, { env: o.env });
    const r = spawnSync("npx", ["playwright", "test", "--grep", ticket.toUpperCase(), ...cmd.args.filter((a) => a !== ticket)], { stdio: "inherit", cwd: root, env: { ...process.env, QA_ENV: envKey, HEADED: o.headed ? "true" : (process.env.HEADED ?? "false") } });
    process.exit(r.status ?? 1);
  });

program.parseAsync(process.argv).catch((e: Error) => {
  console.error(`error: ${e.message}`);
  process.exit(1);
});
