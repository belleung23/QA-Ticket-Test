import fs from "node:fs";
import { chromium, firefox, webkit, type FullConfig } from "@playwright/test";
import { loadConfig, resolveEnvironment, storageStatePath } from "../config/load.js";
import { authenticatedContext, makeAuthContext, saveStorageState, strategyFor } from "./strategies.js";

/**
 * Runs once before the suite. For `form` / `script` strategies it logs in once
 * and saves a storage state so every worker starts authenticated without
 * re-logging. For `storage-state` it just verifies the file exists.
 */
export default async function globalSetup(_config: FullConfig): Promise<void> {
  const cfg = loadConfig();
  const { key, env } = resolveEnvironment(cfg);
  const ctx = makeAuthContext(cfg, key, env);
  const strategy = strategyFor(cfg, env);
  if (strategy === "none") return;
  const file = storageStatePath(cfg, key, ctx.root);
  if (strategy === "storage-state") {
    if (!fs.existsSync(file)) throw new Error(`No saved session for "${key}". Run: npm run auth:save -- --env=${key}`);
    return;
  }
  const launcher = { chromium, firefox, webkit }[cfg.playwright.browser];
  const browser = await launcher.launch({ headless: true });
  try {
    const context = await authenticatedContext(browser, ctx);
    await saveStorageState(context, ctx);
    await context.close();
  } finally {
    await browser.close();
  }
}
