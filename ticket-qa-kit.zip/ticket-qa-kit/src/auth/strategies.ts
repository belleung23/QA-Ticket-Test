import fs from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import type { Browser, BrowserContext, Page } from "@playwright/test";
import { findRepoRoot, storageStatePath, type EnvironmentConfig, type QaConfig } from "../config/load.js";

export interface AuthContext {
  cfg: QaConfig;
  envKey: string;
  env: EnvironmentConfig;
  root: string;
}

export type CustomLogin = (page: Page, ctx: AuthContext) => Promise<void>;

/** Which strategy applies for this environment (per-env override wins). */
export function strategyFor(cfg: QaConfig, env: EnvironmentConfig): QaConfig["auth"]["strategy"] {
  return env.authStrategy ?? cfg.auth.strategy;
}

/** Log a fresh page in using the `form` strategy. Credentials come only from config/env. */
export async function formLogin(page: Page, ctx: AuthContext): Promise<void> {
  const f = ctx.cfg.auth.form;
  if (!f) throw new Error("auth.strategy is 'form' but auth.form is not configured in qa.config.yaml");
  if (!f.username || !f.password) throw new Error("form login: APP_USERNAME / APP_PASSWORD are empty (set them in .env)");
  await page.goto(new URL(f.loginPath, ctx.env.baseUrl).toString());
  await page.locator(f.usernameSelector).fill(f.username);
  await page.locator(f.passwordSelector).fill(f.password);
  await page.locator(f.submitSelector).click();
  if (f.loggedInSelector) await page.locator(f.loggedInSelector).first().waitFor({ state: "visible", timeout: ctx.cfg.playwright.timeoutMs });
  else await page.waitForLoadState("networkidle");
}

export async function scriptLogin(page: Page, ctx: AuthContext): Promise<void> {
  const rel = ctx.cfg.auth.script?.path;
  if (!rel) throw new Error("auth.strategy is 'script' but auth.script.path is not set");
  const abs = path.resolve(ctx.root, rel);
  if (!fs.existsSync(abs)) throw new Error(`auth script not found: ${abs}`);
  const mod = (await import(pathToFileURL(abs).href)) as { login?: CustomLogin; default?: CustomLogin };
  const fn = mod.login ?? mod.default;
  if (typeof fn !== "function") throw new Error(`${abs} must export \`login(page, ctx)\``);
  await fn(page, ctx);
}

/**
 * Produce a logged-in BrowserContext for the chosen strategy.
 * - none          → plain context
 * - storage-state → load .auth/<env>.storage-state.json (run `npm run auth:save` first)
 * - form / script → log in once here; the caller may then save state for reuse
 */
export async function authenticatedContext(browser: Browser, ctx: AuthContext): Promise<BrowserContext> {
  const strategy = strategyFor(ctx.cfg, ctx.env);
  if (strategy === "none") return browser.newContext({ baseURL: ctx.env.baseUrl });
  if (strategy === "storage-state") {
    const file = storageStatePath(ctx.cfg, ctx.envKey, ctx.root);
    if (!fs.existsSync(file)) {
      throw new Error(`No saved session for "${ctx.envKey}" at ${path.relative(ctx.root, file)}.\nRun: npm run auth:save -- --env=${ctx.envKey}   (log in by hand once; the session is saved and reused)`);
    }
    return browser.newContext({ baseURL: ctx.env.baseUrl, storageState: file });
  }
  const context = await browser.newContext({ baseURL: ctx.env.baseUrl });
  const page = await context.newPage();
  if (strategy === "form") await formLogin(page, ctx);
  else await scriptLogin(page, ctx);
  await page.close();
  return context;
}

export async function saveStorageState(context: BrowserContext, ctx: AuthContext): Promise<string> {
  const file = storageStatePath(ctx.cfg, ctx.envKey, ctx.root);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  await context.storageState({ path: file });
  return file;
}

export function makeAuthContext(cfg: QaConfig, envKey: string, env: EnvironmentConfig): AuthContext {
  return { cfg, envKey, env, root: findRepoRoot() };
}
