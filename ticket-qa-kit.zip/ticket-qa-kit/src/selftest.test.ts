// Unit tests for the pure parts of the kit (no network, no browser). Run: npm run selftest
import { test } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { findRepoRoot, interpolateEnv, resolveEnvironment } from "./config/load.js";
import { configSchema } from "./config/schema.js";
import { adfToMarkdown, markdownToAdf } from "./trackers/jira.js";
import { extractPrUrls, type Ticket } from "./trackers/types.js";
import { analyzeTicket, splitSections } from "./analyze/requirements.js";
import { parseTestCaseTable, renderTestCaseTable, summarize } from "./report/testcases.js";
import { scaffoldSpec } from "./analyze/scaffold-spec.js";

const root = findRepoRoot();

const baseConfig = configSchema.parse({
  project: { name: "Demo" },
  tracker: { kind: "linear" },
  environments: { dev: { baseUrl: "https://dev.example.com" }, prod: { baseUrl: "https://example.com", readOnly: true } },
  defaultEnvironment: "dev",
  environmentHints: { prod: ["[Prod]"] },
  auth: { strategy: "none" },
});

test("env interpolation supports ${VAR} and ${VAR:-default}", () => {
  assert.equal(interpolateEnv("${A}/${B:-x}/${C}", { A: "a" }), "a/x/");
});

test("environment resolution: explicit > QA_ENV > title hint > default", () => {
  delete process.env.QA_ENV;
  delete process.env.APP_BASE_URL;
  assert.equal(resolveEnvironment(baseConfig).key, "dev");
  assert.equal(resolveEnvironment(baseConfig, { ticketTitle: "[Prod] hotfix" }).key, "prod");
  assert.equal(resolveEnvironment(baseConfig, { env: "prod", ticketTitle: "x" }).key, "prod");
  assert.throws(() => resolveEnvironment(baseConfig, { env: "nope" }), /Unknown environment/);
  process.env.APP_BASE_URL = "https://override.example.com";
  assert.equal(resolveEnvironment(baseConfig).env.baseUrl, "https://override.example.com");
  delete process.env.APP_BASE_URL;
});

test("empty ${VAR} values fall back to schema defaults", () => {
  const r = configSchema.parse({ ...baseConfig, tracker: { kind: "jira", jira: { auth: undefined } } });
  assert.equal(r.tracker.jira.auth, "basic");
});

test("config validation rejects a missing defaultEnvironment target", () => {
  const r = configSchema.safeParse({ ...baseConfig, environments: {} });
  assert.equal(r.success, false);
});

test("ADF → markdown keeps lists, headings, checkboxes and tables", () => {
  const adf = {
    type: "doc",
    content: [
      { type: "heading", attrs: { level: 2 }, content: [{ type: "text", text: "Acceptance Criteria" }] },
      { type: "taskList", content: [{ type: "taskItem", attrs: { state: "TODO" }, content: [{ type: "text", text: "Saves on Enter" }] }] },
      { type: "bulletList", content: [{ type: "listItem", content: [{ type: "paragraph", content: [{ type: "text", text: "bold", marks: [{ type: "strong" }] }] }] }] },
      { type: "table", content: [{ type: "tableRow", content: [{ type: "tableHeader", content: [{ type: "paragraph", content: [{ type: "text", text: "A" }] }] }] }, { type: "tableRow", content: [{ type: "tableCell", content: [{ type: "paragraph", content: [{ type: "text", text: "1" }] }] }] }] },
    ],
  };
  const md = adfToMarkdown(adf);
  assert.match(md, /## Acceptance Criteria/);
  assert.match(md, /- \[ \] Saves on Enter/);
  assert.match(md, /- \*\*bold\*\*/);
  assert.match(md, /\| A \|\n\| --- \|\n\| 1 \|/);
  const back = markdownToAdf("## Title\n\nhello\n\n```ts\nx\n```");
  assert.equal(back.content?.length, 3);
  assert.equal(back.content?.[2].type, "codeBlock");
});

test("PR URL extraction covers GitHub/GitLab/Bitbucket", () => {
  const urls = extractPrUrls("see https://github.com/o/r/pull/12 and https://gitlab.com/g/p/-/merge_requests/3", "https://bitbucket.org/w/r/pull-requests/9.");
  assert.equal(urls.length, 3);
});

function demoTicket(): Ticket {
  const md = fs.readFileSync(path.join(root, "examples/DEMO-42/ticket.md"), "utf8");
  const description = md.slice(md.indexOf("## Description") + "## Description".length);
  return { tracker: "linear", key: "DEMO-42", id: "x", url: "https://linear.app/example/issue/DEMO-42", title: "Users can rename a saved filter", type: "Story", status: "In QA", labels: [], description, comments: [], attachments: [], links: [], pullRequests: ["https://github.com/example/app/pull/318"], createdAt: "", updatedAt: "" };
}

test("requirement analysis extracts the 7 checkbox ACs and the out-of-scope line", () => {
  const a = analyzeTicket(demoTicket(), baseConfig);
  assert.equal(a.requirements.length, 7, JSON.stringify(a.requirements.map((r) => r.text)));
  assert.equal(a.requirements[0].id, "AC1");
  assert.match(a.requirements[6].text, /Viewers/);
  assert.equal(a.outOfScope.length, 1);
  assert.equal(a.clarifications.length, 0);
  assert.ok(splitSections("# A\nx\n## B\ny").length === 2);
});

test("vague wording and missing PR produce clarifications", () => {
  const t = demoTicket();
  t.description = "## Acceptance Criteria\n- the page should work properly\n";
  t.pullRequests = [];
  const a = analyzeTicket(t, baseConfig);
  assert.equal(a.requirements.length, 1);
  assert.ok(a.clarifications.some((c) => /vague/.test(c)));
  assert.ok(a.clarifications.some((c) => /pull request/i.test(c)));
});

test("manual.md table round-trips and summarizes", () => {
  const md = fs.readFileSync(path.join(root, "examples/DEMO-42/manual.md"), "utf8");
  const tcs = parseTestCaseTable(md);
  assert.equal(tcs.length, 7);
  assert.deepEqual(tcs[0].steps.length, 3);
  assert.equal(tcs[4].status, "Fail");
  assert.equal(tcs.filter((t) => t.automate === "yes").length, 6);
  const s = summarize(tcs);
  assert.equal(s.verdict, "FAILED");
  assert.equal(s.pass, 6);
  const again = parseTestCaseTable(renderTestCaseTable(tcs));
  assert.deepEqual(again, tcs);
});

test("spec scaffold emits one test per Automate=yes row, tagged and guarded", () => {
  const tcs = parseTestCaseTable(fs.readFileSync(path.join(root, "examples/DEMO-42/manual.md"), "utf8"));
  const src = scaffoldSpec({ ticketKey: "DEMO-42", ticketTitle: "Users can rename a saved filter", testCases: tcs, cfg: baseConfig });
  assert.equal((src.match(/^\s+test\("TC\d+/gm) ?? []).length, 6);
  assert.match(src, /@DEMO-42 @TC2 @High @happy-path @regression/);
  assert.match(src, /assertWritable\(env, envKey\)/);
  assert.match(src, /async \(\{ page \}\) =>/, "read-only cases must not destructure unused fixtures");
  assert.doesNotMatch(src, /https?:\/\//, "scaffold must not contain URLs");
});
