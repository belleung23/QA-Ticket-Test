/**
 * The manual test-case file (test-cases/<KEY>/manual.md) is a Markdown table.
 * Its column order is an interface contract shared by the agent skills, the
 * report generator and the automation generator. Do not rename or reorder.
 */
export const TC_COLUMNS = ["#", "AC", "Priority", "Type", "Test Description", "Test Steps", "Expected Result", "Actual Result", "Status", "Evidence", "Automate"] as const;
export type TcColumn = (typeof TC_COLUMNS)[number];

export type TcStatus = "Pass" | "Fail" | "Blocked" | "Skipped" | "—";
export type TcType = "Happy Path" | "Negative" | "Edge Case" | "Regression";
export type TcPriority = "High" | "Medium" | "Low";

export interface TestCase {
  n: number;
  ac: string; // "AC1" or "AC1, AC3"
  priority: TcPriority;
  type: TcType;
  description: string;
  steps: string[]; // numbered steps
  expected: string;
  actual: string;
  status: TcStatus;
  evidence: string; // relative path(s) or "—"
  automate: "yes" | "no" | "—"; // approved for automation?
}

const esc = (s: string) => s.replace(/\|/g, "\\|").replace(/\n+/g, "<br>");
const unesc = (s: string) => s.replace(/<br\s*\/?>/gi, "\n").replace(/\\\|/g, "|").trim();

export function renderTestCaseTable(tcs: TestCase[]): string {
  const head = `| ${TC_COLUMNS.join(" | ")} |`;
  const sep = `| ${TC_COLUMNS.map(() => "---").join(" | ")} |`;
  const rows = tcs.map((t) =>
    `| ${t.n} | ${esc(t.ac)} | ${t.priority} | ${t.type} | ${esc(t.description)} | ${esc(t.steps.map((s, i) => `${i + 1}. ${s}`).join("\n"))} | ${esc(t.expected)} | ${esc(t.actual)} | ${t.status} | ${esc(t.evidence)} | ${t.automate} |`,
  );
  return [head, sep, ...rows].join("\n");
}

/** Parse the first table whose header matches TC_COLUMNS. Tolerates extra whitespace. */
export function parseTestCaseTable(md: string): TestCase[] {
  const lines = md.replace(/\r\n/g, "\n").split("\n");
  const headerIdx = lines.findIndex((l) => {
    const cells = splitRow(l);
    return cells.length >= 9 && cells[0] === "#" && /test description/i.test(cells[4] ?? "");
  });
  if (headerIdx < 0) return [];
  const header = splitRow(lines[headerIdx]).map((c) => c.toLowerCase());
  const col = (name: string) => header.findIndex((h) => h === name.toLowerCase());
  const out: TestCase[] = [];
  for (let i = headerIdx + 2; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim().startsWith("|")) break;
    const c = splitRow(line);
    const n = Number(c[col("#")]);
    if (!Number.isFinite(n)) continue;
    const stepsRaw = unesc(c[col("Test Steps")] ?? "");
    const steps = stepsRaw.split("\n").map((s) => s.replace(/^\s*\d+[.)]\s*/, "").trim()).filter(Boolean);
    const statusRaw = (c[col("Status")] ?? "—").replace(/[^\w—]/g, "");
    const status = (["Pass", "Fail", "Blocked", "Skipped"].find((s) => s.toLowerCase() === statusRaw.toLowerCase()) ?? "—") as TcStatus;
    out.push({
      n,
      ac: unesc(c[col("AC")] ?? ""),
      priority: ((c[col("Priority")] ?? "Medium").trim() as TcPriority) || "Medium",
      type: ((c[col("Type")] ?? "Happy Path").trim() as TcType) || "Happy Path",
      description: unesc(c[col("Test Description")] ?? ""),
      steps,
      expected: unesc(c[col("Expected Result")] ?? ""),
      actual: unesc(c[col("Actual Result")] ?? "—"),
      status,
      evidence: unesc(c[col("Evidence")] ?? "—"),
      automate: ((c[col("Automate")] ?? "—").trim().toLowerCase() as "yes" | "no" | "—") || "—",
    });
  }
  return out;
}

function splitRow(line: string): string[] {
  // split on unescaped pipes, drop the leading/trailing empties
  const cells: string[] = [];
  let cur = "";
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (ch === "\\" && line[i + 1] === "|") {
      cur += "\\|";
      i++;
    } else if (ch === "|") {
      cells.push(cur.trim());
      cur = "";
    } else cur += ch;
  }
  cells.push(cur.trim());
  if (cells[0] === "") cells.shift();
  if (cells[cells.length - 1] === "") cells.pop();
  return cells;
}

export function summarize(tcs: TestCase[]) {
  const count = (s: TcStatus) => tcs.filter((t) => t.status === s).length;
  const s = { total: tcs.length, pass: count("Pass"), fail: count("Fail"), blocked: count("Blocked"), skipped: count("Skipped"), notRun: count("—") };
  const verdict: "PASSED" | "FAILED" | "INCOMPLETE" = s.fail > 0 ? "FAILED" : s.blocked + s.notRun > 0 ? "INCOMPLETE" : "PASSED";
  return { ...s, verdict };
}
