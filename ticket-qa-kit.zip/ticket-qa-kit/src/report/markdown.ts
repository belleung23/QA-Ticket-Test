import type { Analysis } from "../analyze/requirements.js";
import { renderTestCaseTable, summarize, type TestCase } from "./testcases.js";

export interface ReportInput {
  projectName: string;
  ticketKey: string;
  ticketTitle: string;
  ticketUrl: string;
  environmentKey: string;
  baseUrl: string;
  tester: string; // whoever ran it — a person's name; never an AI tool name
  date: string; // YYYY-MM-DD
  mode: "manual" | "automation";
  testCases: TestCase[];
  analysis?: Analysis;
  /** Free-form notes: root cause of failures, flaky observations, env issues */
  notes?: string[];
  /** Bugs filed as a result: key → title */
  bugsFiled?: Array<{ key: string; url?: string; title: string }>;
}

export function renderReport(r: ReportInput): string {
  const s = summarize(r.testCases);
  const L: string[] = [];
  L.push(`# QA Report — ${r.ticketKey}: ${r.ticketTitle}`, "");
  L.push(`| | |`, `|---|---|`);
  L.push(`| **Verdict** | **${s.verdict}** |`);
  L.push(`| Project | ${r.projectName} |`);
  L.push(`| Ticket | [${r.ticketKey}](${r.ticketUrl}) |`);
  L.push(`| Environment | \`${r.environmentKey}\` — ${r.baseUrl} |`);
  L.push(`| Mode | ${r.mode === "manual" ? "Manual (agent-driven browser)" : "Automation (Playwright)"} |`);
  L.push(`| Tester | ${r.tester} |`);
  L.push(`| Date | ${r.date} |`, "");
  L.push("## Execution summary", "");
  L.push(`- Total: ${s.total}`, `- ✅ Pass: ${s.pass}`, `- ❌ Fail: ${s.fail}`, `- ⛔ Blocked: ${s.blocked}`, `- ⏭️ Skipped: ${s.skipped}`, `- ⬜ Not run: ${s.notRun}`, "");
  if (r.analysis) {
    L.push("## AC coverage", "");
    L.push("| AC | Requirement | Test cases | Result |", "|---|---|---|---|");
    for (const ac of r.analysis.requirements) {
      const tcs = r.testCases.filter((t) => t.ac.split(/[,\s]+/).includes(ac.id));
      const res = tcs.length === 0 ? "⚠️ uncovered" : tcs.some((t) => t.status === "Fail") ? "❌" : tcs.every((t) => t.status === "Pass") ? "✅" : "⬜";
      L.push(`| ${ac.id} | ${ac.text.replace(/\|/g, "\\|")} | ${tcs.map((t) => `#${t.n}`).join(", ") || "—"} | ${res} |`);
    }
    L.push("");
  }
  L.push("## Test cases", "", renderTestCaseTable(r.testCases), "");
  const fails = r.testCases.filter((t) => t.status === "Fail");
  if (fails.length) {
    L.push("## Failures", "");
    for (const f of fails) {
      L.push(`### #${f.n} — ${f.description}`, "");
      L.push(`**Expected:** ${f.expected}  `, `**Actual:** ${f.actual}  `, `**Evidence:** ${f.evidence}`, "");
      L.push("**Steps to reproduce**", "");
      f.steps.forEach((st, i) => L.push(`${i + 1}. ${st}`));
      L.push("");
    }
  }
  if (r.bugsFiled?.length) {
    L.push("## Bugs filed", "");
    for (const b of r.bugsFiled) L.push(`- ${b.url ? `[${b.key}](${b.url})` : b.key} — ${b.title}`);
    L.push("");
  }
  if (r.notes?.length) {
    L.push("## Notes", "");
    for (const n of r.notes) L.push(`- ${n}`);
    L.push("");
  }
  return L.join("\n");
}

/** Short version for posting back on the ticket. */
export function renderTicketComment(r: ReportInput): string {
  const s = summarize(r.testCases);
  const icon = s.verdict === "PASSED" ? "✅" : s.verdict === "FAILED" ? "❌" : "⚠️";
  const L: string[] = [];
  L.push(`## ${icon} QA ${s.verdict} — ${r.environmentKey} (${r.date})`, "");
  L.push(`Tested on ${r.baseUrl} by ${r.tester}, ${r.mode} mode.`, "");
  L.push(`**${s.pass}/${s.total} passed** · ${s.fail} failed · ${s.blocked} blocked · ${s.skipped} skipped`, "");
  L.push("| # | Test Case | Status | Expected | Actual | Evidence |", "|---|---|---|---|---|---|");
  for (const t of r.testCases) {
    const st = t.status === "Pass" ? "✅ Pass" : t.status === "Fail" ? "❌ Fail" : t.status === "Blocked" ? "⛔ Blocked" : t.status;
    L.push(`| ${t.n} | ${t.description.replace(/\|/g, "\\|")} | ${st} | ${t.expected.replace(/\|/g, "\\|")} | ${t.actual.replace(/\|/g, "\\|")} | ${t.evidence} |`);
  }
  L.push("");
  if (r.bugsFiled?.length) {
    L.push("**Bugs filed:** " + r.bugsFiled.map((b) => (b.url ? `[${b.key}](${b.url})` : b.key)).join(", "), "");
  }
  return L.join("\n");
}
