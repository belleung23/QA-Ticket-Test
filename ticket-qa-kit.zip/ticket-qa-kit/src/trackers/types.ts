/** Tracker-neutral ticket model. Both adapters normalise into this shape. */
export interface TicketComment {
  author: string;
  createdAt: string;
  /** Markdown */
  body: string;
}

export interface TicketAttachment {
  title: string;
  url: string;
}

export interface TicketLink {
  /** e.g. "blocks", "relates to", "duplicate of", "parent", "sub-task" */
  relation: string;
  key: string;
  title?: string;
}

export interface Ticket {
  tracker: "linear" | "jira";
  key: string; // FRAI-123 / PROJ-456
  id: string; // tracker-internal id
  url: string;
  title: string;
  type?: string; // Bug, Story, Task…
  status: string;
  priority?: string;
  labels: string[];
  assignee?: string;
  reporter?: string;
  /** Markdown description, as written by the author */
  description: string;
  /** Jira only: value of the configured Acceptance Criteria custom field, if any */
  acceptanceCriteriaField?: string;
  comments: TicketComment[];
  attachments: TicketAttachment[];
  links: TicketLink[];
  /** Pull-request URLs found in attachments / links / description */
  pullRequests: string[];
  createdAt: string;
  updatedAt: string;
}

export interface TrackerAdapter {
  readonly kind: "linear" | "jira";
  getTicket(key: string): Promise<Ticket>;
  addComment(key: string, markdown: string): Promise<{ id: string; url?: string }>;
  /** Move to a workflow state / transition by its display name. */
  setStatus(key: string, statusName: string): Promise<void>;
  listStatuses(key: string): Promise<string[]>;
}

export const PR_URL_RE = /https?:\/\/(?:github\.com|gitlab\.com|bitbucket\.org)\/[^\s)>\]"']+\/(?:pull|merge_requests|pull-requests)\/\d+/g;

export function extractPrUrls(...texts: Array<string | undefined>): string[] {
  const set = new Set<string>();
  for (const t of texts) for (const m of (t ?? "").matchAll(PR_URL_RE)) set.add(m[0]);
  return [...set];
}
