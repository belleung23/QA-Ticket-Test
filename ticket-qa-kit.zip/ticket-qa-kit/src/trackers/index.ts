import type { QaConfig } from "../config/schema.js";
import { JiraAdapter } from "./jira.js";
import { LinearAdapter } from "./linear.js";
import type { TrackerAdapter } from "./types.js";

export function createTracker(cfg: QaConfig): TrackerAdapter {
  switch (cfg.tracker.kind) {
    case "linear":
      return new LinearAdapter(cfg.tracker.linear);
    case "jira":
      return new JiraAdapter(cfg.tracker.jira);
  }
}

export * from "./types.js";
