import type { QaConfig } from "../config/schema.js";
import { httpRequest } from "../net/http.js";
import { extractPrUrls, type Ticket, type TrackerAdapter } from "./types.js";

const ENDPOINT = "https://api.linear.app/graphql";

interface GqlResponse<T> {
  data?: T;
  errors?: Array<{ message: string }>;
}

export class LinearAdapter implements TrackerAdapter {
  readonly kind = "linear" as const;
  constructor(private readonly cfg: QaConfig["tracker"]["linear"]) {}

  private async gql<T>(query: string, variables: Record<string, unknown> = {}): Promise<T> {
    const headers: Record<string, string> = { "Content-Type": "application/json" };
    // Linear personal API keys are sent raw; OAuth tokens as "Bearer …".
    if (this.cfg.apiKey) headers.Authorization = this.cfg.apiKey.startsWith("lin_oauth_") ? `Bearer ${this.cfg.apiKey}` : this.cfg.apiKey;
    const res = await httpRequest(ENDPOINT, { method: "POST", headers, body: JSON.stringify({ query, variables }) });
    if (res.status < 200 || res.status >= 300) throw new Error(`Linear API ${res.status}: ${res.text}`);
    const json = res.json<GqlResponse<T>>();
    if (json.errors?.length) throw new Error(`Linear GraphQL: ${json.errors.map((e) => e.message).join("; ")}`);
    if (!json.data) throw new Error("Linear GraphQL: empty response");
    return json.data;
  }

  async getTicket(key: string): Promise<Ticket> {
    type R = {
      issue: {
        id: string; identifier: string; url: string; title: string; description: string | null;
        priorityLabel: string; createdAt: string; updatedAt: string;
        state: { name: string; type: string };
        assignee: { name: string } | null; creator: { name: string } | null;
        labels: { nodes: Array<{ name: string }> };
        parent: { identifier: string; title: string } | null;
        children: { nodes: Array<{ identifier: string; title: string }> };
        relations: { nodes: Array<{ type: string; relatedIssue: { identifier: string; title: string } }> };
        inverseRelations: { nodes: Array<{ type: string; issue: { identifier: string; title: string } }> };
        attachments: { nodes: Array<{ title: string; url: string }> };
        comments: { nodes: Array<{ body: string; createdAt: string; user: { name: string } | null }> };
      } | null;
    };
    const data = await this.gql<R>(
      `query($id: String!) {
        issue(id: $id) {
          id identifier url title description priorityLabel createdAt updatedAt
          state { name type }
          assignee { name } creator { name }
          labels { nodes { name } }
          parent { identifier title }
          children { nodes { identifier title } }
          relations { nodes { type relatedIssue { identifier title } } }
          inverseRelations { nodes { type issue { identifier title } } }
          attachments { nodes { title url } }
          comments(first: 100, orderBy: createdAt) { nodes { body createdAt user { name } } }
        }
      }`,
      { id: key },
    );
    const i = data.issue;
    if (!i) throw new Error(`Linear issue ${key} not found (check the key and your API access).`);
    const attachments = i.attachments.nodes;
    const links = [
      ...(i.parent ? [{ relation: "parent", key: i.parent.identifier, title: i.parent.title }] : []),
      ...i.children.nodes.map((c) => ({ relation: "sub-issue", key: c.identifier, title: c.title })),
      ...i.relations.nodes.map((r) => ({ relation: r.type, key: r.relatedIssue.identifier, title: r.relatedIssue.title })),
      ...i.inverseRelations.nodes.map((r) => ({ relation: `${r.type} (inverse)`, key: r.issue.identifier, title: r.issue.title })),
    ];
    return {
      tracker: "linear",
      key: i.identifier,
      id: i.id,
      url: i.url,
      title: i.title,
      status: i.state.name,
      priority: i.priorityLabel,
      labels: i.labels.nodes.map((l) => l.name),
      assignee: i.assignee?.name,
      reporter: i.creator?.name,
      description: i.description ?? "",
      comments: i.comments.nodes.map((c) => ({ author: c.user?.name ?? "unknown", createdAt: c.createdAt, body: c.body })),
      attachments,
      links,
      pullRequests: extractPrUrls(i.description ?? "", ...attachments.map((a) => a.url), ...i.comments.nodes.map((c) => c.body)),
      createdAt: i.createdAt,
      updatedAt: i.updatedAt,
    };
  }

  async addComment(key: string, markdown: string): Promise<{ id: string; url?: string }> {
    const t = await this.getTicket(key);
    const data = await this.gql<{ commentCreate: { success: boolean; comment: { id: string; url: string } } }>(
      `mutation($issueId: String!, $body: String!) { commentCreate(input: { issueId: $issueId, body: $body }) { success comment { id url } } }`,
      { issueId: t.id, body: markdown },
    );
    if (!data.commentCreate.success) throw new Error("Linear: commentCreate returned success=false");
    return data.commentCreate.comment;
  }

  private async teamStates(key: string): Promise<Array<{ id: string; name: string }>> {
    const data = await this.gql<{ issue: { team: { states: { nodes: Array<{ id: string; name: string }> } } } | null }>(
      `query($id: String!) { issue(id: $id) { team { states { nodes { id name } } } } }`,
      { id: key },
    );
    if (!data.issue) throw new Error(`Linear issue ${key} not found`);
    return data.issue.team.states.nodes;
  }

  async listStatuses(key: string): Promise<string[]> {
    return (await this.teamStates(key)).map((s) => s.name);
  }

  async setStatus(key: string, statusName: string): Promise<void> {
    const states = await this.teamStates(key);
    const target = states.find((s) => s.name.toLowerCase() === statusName.toLowerCase());
    if (!target) throw new Error(`Linear: no state named "${statusName}". Available: ${states.map((s) => s.name).join(", ")}`);
    const t = await this.getTicket(key);
    const data = await this.gql<{ issueUpdate: { success: boolean } }>(
      `mutation($id: String!, $stateId: String!) { issueUpdate(id: $id, input: { stateId: $stateId }) { success } }`,
      { id: t.id, stateId: target.id },
    );
    if (!data.issueUpdate.success) throw new Error("Linear: issueUpdate returned success=false");
  }
}
