import type { QaConfig } from "../config/schema.js";
import { httpRequest } from "../net/http.js";
import { extractPrUrls, type Ticket, type TrackerAdapter } from "./types.js";

/* ---------- Atlassian Document Format → Markdown (good-enough, lossless on text) ---------- */

type AdfNode = {
  type: string;
  text?: string;
  attrs?: Record<string, unknown>;
  marks?: Array<{ type: string; attrs?: Record<string, unknown> }>;
  content?: AdfNode[];
};

function inline(n: AdfNode): string {
  if (n.type === "text") {
    let t = n.text ?? "";
    for (const m of n.marks ?? []) {
      if (m.type === "strong") t = `**${t}**`;
      else if (m.type === "em") t = `*${t}*`;
      else if (m.type === "code") t = `\`${t}\``;
      else if (m.type === "strike") t = `~~${t}~~`;
      else if (m.type === "link") t = `[${t}](${String(m.attrs?.href ?? "")})`;
    }
    return t;
  }
  if (n.type === "hardBreak") return "\n";
  if (n.type === "mention") return `@${String(n.attrs?.text ?? n.attrs?.id ?? "")}`;
  if (n.type === "emoji") return String(n.attrs?.text ?? n.attrs?.shortName ?? "");
  if (n.type === "inlineCard") return String(n.attrs?.url ?? "");
  if (n.type === "status") return `[${String(n.attrs?.text ?? "")}]`;
  if (n.type === "date") return String(n.attrs?.timestamp ?? "");
  return (n.content ?? []).map(inline).join("");
}

export function adfToMarkdown(doc: AdfNode | null | undefined, depth = 0): string {
  if (!doc) return "";
  const indent = "  ".repeat(depth);
  const block = (n: AdfNode): string => {
    switch (n.type) {
      case "doc":
        return (n.content ?? []).map(block).filter(Boolean).join("\n\n");
      case "paragraph":
        return indent + inline(n);
      case "heading":
        return `${"#".repeat(Number(n.attrs?.level ?? 1))} ${inline(n)}`;
      case "bulletList":
        return (n.content ?? []).map((li) => `${indent}- ${adfToMarkdown({ type: "doc", content: li.content }, depth + 1).trimStart()}`).join("\n");
      case "orderedList":
        return (n.content ?? [])
          .map((li, i) => `${indent}${i + 1}. ${adfToMarkdown({ type: "doc", content: li.content }, depth + 1).trimStart()}`)
          .join("\n");
      case "taskList":
        return (n.content ?? [])
          .map((li) => `${indent}- [${li.attrs?.state === "DONE" ? "x" : " "}] ${inline(li)}`)
          .join("\n");
      case "codeBlock":
        return `\`\`\`${String(n.attrs?.language ?? "")}\n${(n.content ?? []).map((c) => c.text ?? "").join("")}\n\`\`\``;
      case "blockquote":
        return adfToMarkdown({ type: "doc", content: n.content }, depth).split("\n").map((l) => `> ${l}`).join("\n");
      case "panel":
        return `> **${String(n.attrs?.panelType ?? "note").toUpperCase()}**\n${adfToMarkdown({ type: "doc", content: n.content }, depth).split("\n").map((l) => `> ${l}`).join("\n")}`;
      case "rule":
        return "---";
      case "table": {
        const rows = (n.content ?? []).map((row) => (row.content ?? []).map((cell) => adfToMarkdown({ type: "doc", content: cell.content }).replace(/\n+/g, " ").trim()));
        if (!rows.length) return "";
        const header = rows[0];
        const sep = header.map(() => "---");
        return [header, sep, ...rows.slice(1)].map((r) => `| ${r.join(" | ")} |`).join("\n");
      }
      case "mediaSingle":
      case "mediaGroup":
        return (n.content ?? []).map((m) => `![${String(m.attrs?.alt ?? "attachment")}](${String(m.attrs?.url ?? m.attrs?.id ?? "")})`).join("\n");
      case "expand":
      case "nestedExpand":
        return `<details><summary>${String(n.attrs?.title ?? "")}</summary>\n\n${adfToMarkdown({ type: "doc", content: n.content }, depth)}\n\n</details>`;
      default:
        return n.content ? adfToMarkdown({ type: "doc", content: n.content }, depth) : inline(n);
    }
  };
  return block(doc);
}

/** Plain markdown-ish text → minimal ADF (paragraphs; fenced code preserved). */
export function markdownToAdf(md: string): AdfNode {
  const content: AdfNode[] = [];
  const lines = md.split("\n");
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (line.startsWith("```")) {
      const lang = line.slice(3).trim();
      const buf: string[] = [];
      i++;
      while (i < lines.length && !lines[i].startsWith("```")) buf.push(lines[i++]);
      i++;
      content.push({ type: "codeBlock", attrs: lang ? { language: lang } : {}, content: [{ type: "text", text: buf.join("\n") }] });
      continue;
    }
    const h = /^(#{1,6})\s+(.*)$/.exec(line);
    if (h) {
      content.push({ type: "heading", attrs: { level: h[1].length }, content: [{ type: "text", text: h[2] }] });
      i++;
      continue;
    }
    if (line.trim() === "") {
      i++;
      continue;
    }
    const para: string[] = [];
    while (i < lines.length && lines[i].trim() !== "" && !lines[i].startsWith("```") && !/^#{1,6}\s/.test(lines[i])) para.push(lines[i++]);
    content.push({ type: "paragraph", content: [{ type: "text", text: para.join("\n") }] });
  }
  return { type: "doc", version: 1, content } as AdfNode & { version: number };
}

/* ---------- Adapter ---------- */

export class JiraAdapter implements TrackerAdapter {
  readonly kind = "jira" as const;
  constructor(private readonly cfg: QaConfig["tracker"]["jira"]) {
    if (!cfg.baseUrl) throw new Error("Jira: JIRA_BASE_URL is not set (see .env.example).");
  }

  private get base(): string {
    return this.cfg.baseUrl.replace(/\/+$/, "");
  }

  private headers(): Record<string, string> {
    const h: Record<string, string> = { Accept: "application/json", "Content-Type": "application/json" };
    if (this.cfg.auth === "bearer") {
      if (this.cfg.apiToken) h.Authorization = `Bearer ${this.cfg.apiToken}`;
    } else if (this.cfg.email && this.cfg.apiToken) {
      h.Authorization = `Basic ${Buffer.from(`${this.cfg.email}:${this.cfg.apiToken}`).toString("base64")}`;
    }
    return h;
  }

  private async req<T>(method: string, pathname: string, body?: unknown): Promise<T> {
    const res = await httpRequest(`${this.base}${pathname}`, { method, headers: this.headers(), body: body ? JSON.stringify(body) : undefined });
    if (res.status < 200 || res.status >= 300) throw new Error(`Jira ${method} ${pathname} → ${res.status}: ${res.text}`);
    if (res.status === 204 || !res.text) return undefined as T;
    return res.json<T>();
  }

  async getTicket(key: string): Promise<Ticket> {
    type R = {
      id: string; key: string;
      fields: Record<string, unknown> & {
        summary: string; description: AdfNode | string | null; created: string; updated: string;
        issuetype: { name: string }; status: { name: string }; priority: { name: string } | null;
        labels: string[]; assignee: { displayName: string } | null; reporter: { displayName: string } | null;
        parent?: { key: string; fields: { summary: string } };
        subtasks: Array<{ key: string; fields: { summary: string } }>;
        issuelinks: Array<{ type: { name: string; inward: string; outward: string }; inwardIssue?: { key: string; fields: { summary: string } }; outwardIssue?: { key: string; fields: { summary: string } } }>;
        attachment: Array<{ filename: string; content: string }>;
        comment: { comments: Array<{ author: { displayName: string }; created: string; body: AdfNode | string }> };
      };
    };
    const fields = ["summary", "description", "created", "updated", "issuetype", "status", "priority", "labels", "assignee", "reporter", "parent", "subtasks", "issuelinks", "attachment", "comment"];
    if (this.cfg.acceptanceCriteriaField) fields.push(this.cfg.acceptanceCriteriaField);
    const i = await this.req<R>("GET", `/rest/api/3/issue/${encodeURIComponent(key)}?fields=${fields.join(",")}`);
    const f = i.fields;
    const toMd = (v: AdfNode | string | null | undefined) => (typeof v === "string" ? v : adfToMarkdown(v));
    const description = toMd(f.description);
    const acField = this.cfg.acceptanceCriteriaField ? toMd(f[this.cfg.acceptanceCriteriaField] as AdfNode | string | null) : undefined;
    const comments = (f.comment?.comments ?? []).map((c) => ({ author: c.author?.displayName ?? "unknown", createdAt: c.created, body: toMd(c.body) }));
    const attachments = (f.attachment ?? []).map((a) => ({ title: a.filename, url: a.content }));
    const links = [
      ...(f.parent ? [{ relation: "parent", key: f.parent.key, title: f.parent.fields.summary }] : []),
      ...(f.subtasks ?? []).map((s) => ({ relation: "sub-task", key: s.key, title: s.fields.summary })),
      ...(f.issuelinks ?? []).map((l) =>
        l.outwardIssue
          ? { relation: l.type.outward, key: l.outwardIssue.key, title: l.outwardIssue.fields.summary }
          : { relation: l.type.inward, key: l.inwardIssue!.key, title: l.inwardIssue!.fields.summary },
      ),
    ];
    // Dev-panel PRs aren't in the REST issue payload; pick up anything pasted in text.
    const pullRequests = extractPrUrls(description, acField, ...comments.map((c) => c.body));
    return {
      tracker: "jira",
      key: i.key,
      id: i.id,
      url: `${this.base}/browse/${i.key}`,
      title: f.summary,
      type: f.issuetype?.name,
      status: f.status?.name,
      priority: f.priority?.name ?? undefined,
      labels: f.labels ?? [],
      assignee: f.assignee?.displayName,
      reporter: f.reporter?.displayName,
      description,
      acceptanceCriteriaField: acField || undefined,
      comments,
      attachments,
      links,
      pullRequests,
      createdAt: f.created,
      updatedAt: f.updated,
    };
  }

  async addComment(key: string, markdown: string): Promise<{ id: string; url?: string }> {
    const r = await this.req<{ id: string }>("POST", `/rest/api/3/issue/${encodeURIComponent(key)}/comment`, { body: markdownToAdf(markdown) });
    return { id: r.id, url: `${this.base}/browse/${key}?focusedCommentId=${r.id}` };
  }

  private async transitions(key: string): Promise<Array<{ id: string; name: string }>> {
    const r = await this.req<{ transitions: Array<{ id: string; name: string }> }>("GET", `/rest/api/3/issue/${encodeURIComponent(key)}/transitions`);
    return r.transitions;
  }

  async listStatuses(key: string): Promise<string[]> {
    return (await this.transitions(key)).map((t) => t.name);
  }

  async setStatus(key: string, statusName: string): Promise<void> {
    const ts = await this.transitions(key);
    const t = ts.find((x) => x.name.toLowerCase() === statusName.toLowerCase());
    if (!t) throw new Error(`Jira: no transition named "${statusName}" from the current status. Available: ${ts.map((x) => x.name).join(", ")}`);
    await this.req<void>("POST", `/rest/api/3/issue/${encodeURIComponent(key)}/transitions`, { transition: { id: t.id } });
  }
}
