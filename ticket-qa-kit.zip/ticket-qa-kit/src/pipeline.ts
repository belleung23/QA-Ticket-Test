/**
 * The pipeline steps as plain functions. The CLI and the local UI server both
 * call these, so behaviour stays identical whichever way the kit is driven.
 */
import fs from "node:fs";
import path from "node:path";
import { findRepoRoot, loadConfig, resolveEnvironment, type QaConfig } from "./config/load.js";
import { createTracker, type Ticket } from "./trackers/index.js";
import { analyzeTicket, renderAnalysis, type Analysis } from "./analyze/requirements.js";
import { scaffoldSpec, slugify } from "./analyze/scaffold-spec.js";
import { parseTestCaseTable, renderTestCaseTable, summarize, type TestCase } from "./report/testcases.js";
import { renderReport, renderTicketComment, type ReportInput } from "./report/markdown.js";
import type { Recording } from "./recorder/types.js";

export const today = () => new Date().toISOString().slice(0, 10);

export class Kit {
  readonly root: string;
  readonly cfg: QaConfig;
  constructor(root = findRepoRoot()) {
    this.root = root;
    this.cfg = loadConfig({ root });
  }

  /* ---------- paths ---------- */
  ticketDir(key: string) {
    return path.join(this.root, this.cfg.paths.testCases, key);
  }
  manualPath(key: string) {
    return path.join(this.ticketDir(key), "manual.md");
  }
  recordingsDir(key: string) {
    return path.join(this.ticketDir(key), "recordings");
  }
  mediaDir(key: string) {
    return path.join(this.root, this.cfg.paths.media, key);
  }
  specDir(key: string) {
    return path.join(this.root, this.cfg.paths.specs, key);
  }
  rel(p: string) {
    return path.relative(this.root, p).split(path.sep).join("/");
  }
  private write(file: string, content: string) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, content);
    return this.rel(file);
  }

  validateKey(key: string): string {
    const k = key.trim().toUpperCase();
    if (!new RegExp(this.cfg.project.ticketPattern).test(k)) throw new Error(`"${key}" does not match project.ticketPattern (${this.cfg.project.ticketPattern})`);
    return k;
  }

  /* ---------- tracker ---------- */
  async fetch(key: string): Promise<Ticket> {
    key = this.validateKey(key);
    const t = await createTracker(this.cfg).getTicket(key);
    this.write(path.join(this.ticketDir(key), "ticket.json"), JSON.stringify(t, null, 2));
    this.write(path.join(this.ticketDir(key), "ticket.md"), renderTicketMd(t));
    return t;
  }

  readTicket(key: string): Ticket | undefined {
    const f = path.join(this.ticketDir(key), "ticket.json");
    return fs.existsSync(f) ? (JSON.parse(fs.readFileSync(f, "utf8")) as Ticket) : undefined;
  }

  readAnalysis(key: string): Analysis | undefined {
    const f = path.join(this.ticketDir(key), "analysis.json");
    return fs.existsSync(f) ? (JSON.parse(fs.readFileSync(f, "utf8")) as Analysis) : undefined;
  }

  /** fetch + extract requirements + skeleton manual.md (if none). */
  async analyze(key: string, opts: { env?: string } = {}): Promise<{ ticket: Ticket; analysis: Analysis; files: string[]; manualCreated: boolean }> {
    const t = await this.fetch(key);
    key = t.key;
    const a = analyzeTicket(t, this.cfg);
    const files = [
      this.write(path.join(this.ticketDir(key), "analysis.json"), JSON.stringify(a, null, 2)),
      this.write(path.join(this.ticketDir(key), "analysis.md"), renderAnalysis(a, this.cfg)),
    ];
    let manualCreated = false;
    if (!fs.existsSync(this.manualPath(key))) {
      const rows: TestCase[] = a.requirements.map((r, i) => ({ n: i + 1, ac: r.id, priority: "High", type: "Happy Path", description: r.text, steps: ["<fill in from the ticket + the live UI>"], expected: r.text, actual: "—", status: "—", evidence: "—", automate: "—" }));
      this.writeManual(key, rows, opts);
      manualCreated = true;
      files.push(this.rel(this.manualPath(key)));
    }
    return { ticket: t, analysis: a, files, manualCreated };
  }

  /* ---------- manual.md ---------- */
  readManual(key: string): { testCases: TestCase[]; preamble: string } {
    const f = this.manualPath(key);
    if (!fs.existsSync(f)) return { testCases: [], preamble: "" };
    const md = fs.readFileSync(f, "utf8");
    const tableStart = md.search(/^\|\s*#\s*\|/m);
    return { testCases: parseTestCaseTable(md), preamble: tableStart >= 0 ? md.slice(0, tableStart).trimEnd() : md.trimEnd() };
  }

  writeManual(key: string, testCases: TestCase[], opts: { env?: string; preamble?: string } = {}): string {
    const t = this.readTicket(key);
    const { key: envKey, env } = resolveEnvironment(this.cfg, { env: opts.env, ticketTitle: t?.title });
    const preamble =
      opts.preamble?.trim() ||
      [
        `# ${key} — Manual Test Cases`,
        "",
        `Ticket: ${t?.url ?? "—"}  `,
        `Environment: \`${envKey}\` — ${env.baseUrl}  `,
        `Analysis: ./analysis.md`,
        "",
        "> Status vocabulary: Pass | Fail | Blocked | Skipped | — (not run).  ",
        "> Automate = yes marks a case approved for conversion to Playwright (`tqa scaffold`).  ",
        "> Column order is a contract — do not rename or reorder.",
      ].join("\n");
    const normalized = testCases.map((tc, i) => ({ ...tc, n: tc.n || i + 1 }));
    return this.write(this.manualPath(key), `${preamble}\n\n${renderTestCaseTable(normalized)}\n`);
  }

  /* ---------- recordings ---------- */
  readRecording(key: string, n: number): Recording | undefined {
    const f = path.join(this.recordingsDir(key), `TC${n}.json`);
    return fs.existsSync(f) ? (JSON.parse(fs.readFileSync(f, "utf8")) as Recording) : undefined;
  }
  writeRecording(key: string, rec: Recording): string {
    return this.write(path.join(this.recordingsDir(key), `TC${rec.tc}.json`), JSON.stringify(rec, null, 2));
  }

  /* ---------- scaffold ---------- */
  scaffold(key: string, opts: { force?: boolean } = {}): { file: string; count: number; warnings: string[] } {
    key = this.validateKey(key);
    const { testCases } = this.readManual(key);
    if (!testCases.length) throw new Error(`${this.rel(this.manualPath(key))} not found or empty — run analyze and fill it in first`);
    const approved = testCases.filter((t) => t.automate === "yes");
    if (!approved.length) throw new Error("No rows have Automate = yes. Mark the manual cases you want automated first.");
    const warnings: string[] = [];
    const unrun = approved.filter((t) => t.status === "—");
    if (unrun.length) warnings.push(`${unrun.length} approved case(s) were never run manually (#${unrun.map((t) => t.n).join(", #")}).`);
    const title = this.readTicket(key)?.title ?? key;
    const specDir = this.specDir(key);
    const file = path.join(specDir, `${slugify(title)}.spec.ts`);
    if (fs.existsSync(file) && !opts.force) throw new Error(`${this.rel(file)} exists — use force to overwrite`);
    const importPath = path.relative(specDir, path.join(this.root, "src/fixtures/test.js")).split(path.sep).join("/");
    const recordings = Object.fromEntries(approved.map((t) => [t.n, this.readRecording(key, t.n)]).filter(([, r]) => r)) as Record<number, Recording>;
    this.write(file, scaffoldSpec({ ticketKey: key, ticketTitle: title, testCases, cfg: this.cfg, importPath: importPath.startsWith(".") ? importPath : `./${importPath}`, recordings }));
    return { file: this.rel(file), count: approved.length, warnings };
  }

  /* ---------- report ---------- */
  report(key: string, opts: { tester: string; env?: string; mode?: "manual" | "automation"; notes?: string[] }): { reportFile: string; commentFile: string; summary: ReturnType<typeof summarize>; markdown: string } {
    key = this.validateKey(key);
    const t = this.readTicket(key);
    if (!t) throw new Error(`No ticket.json for ${key} — run analyze first`);
    const { testCases } = this.readManual(key);
    const { key: envKey, env } = resolveEnvironment(this.cfg, { env: opts.env, ticketTitle: t.title });
    const input: ReportInput = { projectName: this.cfg.project.name, ticketKey: key, ticketTitle: t.title, ticketUrl: t.url, environmentKey: envKey, baseUrl: env.baseUrl, tester: opts.tester, date: today(), mode: opts.mode ?? "manual", testCases, analysis: this.readAnalysis(key), notes: opts.notes };
    const summary = summarize(testCases);
    const markdown = renderReport(input);
    const reportFile = this.write(path.join(this.root, this.cfg.paths.reports, `${key}_${summary.verdict}_${today()}.md`), markdown);
    const commentFile = this.write(path.join(this.ticketDir(key), "comment.md"), renderTicketComment(input));
    return { reportFile, commentFile, summary, markdown };
  }

  async comment(key: string, body?: string): Promise<{ id: string; url?: string }> {
    key = this.validateKey(key);
    const text = body ?? fs.readFileSync(path.join(this.ticketDir(key), "comment.md"), "utf8");
    return createTracker(this.cfg).addComment(key, text);
  }

  async listStatuses(key: string): Promise<string[]> {
    return createTracker(this.cfg).listStatuses(this.validateKey(key));
  }
  async setStatus(key: string, name: string): Promise<void> {
    return createTracker(this.cfg).setStatus(this.validateKey(key), name);
  }

  /** Tickets that have a folder under test-cases/. */
  listTickets(): Array<{ key: string; title?: string; status?: string; cases: number; summary: ReturnType<typeof summarize> }> {
    const dir = path.join(this.root, this.cfg.paths.testCases);
    if (!fs.existsSync(dir)) return [];
    return fs
      .readdirSync(dir, { withFileTypes: true })
      .filter((d) => d.isDirectory() && new RegExp(this.cfg.project.ticketPattern).test(d.name))
      .map((d) => {
        const t = this.readTicket(d.name);
        const { testCases } = this.readManual(d.name);
        return { key: d.name, title: t?.title, status: t?.status, cases: testCases.length, summary: summarize(testCases) };
      })
      .sort((a, b) => a.key.localeCompare(b.key, undefined, { numeric: true }));
  }
}

export function renderTicketMd(t: Ticket): string {
  return [
    `# ${t.key}: ${t.title}`,
    "",
    `- URL: ${t.url}`,
    `- Type: ${t.type ?? "—"} · Status: ${t.status} · Priority: ${t.priority ?? "—"}`,
    `- Labels: ${t.labels.join(", ") || "—"} · Assignee: ${t.assignee ?? "—"} · Reporter: ${t.reporter ?? "—"}`,
    `- Pull requests: ${t.pullRequests.join(", ") || "none linked"}`,
    `- Links: ${t.links.map((l) => `${l.relation} ${l.key}`).join("; ") || "—"}`,
    `- Attachments: ${t.attachments.map((a) => `[${a.title}](${a.url})`).join(", ") || "—"}`,
    "",
    "## Description",
    "",
    t.description || "_empty_",
    ...(t.acceptanceCriteriaField ? ["", "## Acceptance criteria (field)", "", t.acceptanceCriteriaField] : []),
    "",
    "## Comments",
    "",
    ...(t.comments.length ? t.comments.flatMap((c) => [`### ${c.author} — ${c.createdAt}`, "", c.body, ""]) : ["_none_"]),
  ].join("\n");
}
