import http from "node:http";
import https from "node:https";
import net from "node:net";
import tls from "node:tls";

/**
 * Minimal JSON HTTP client that, unlike Node's global fetch, honours
 * HTTPS_PROXY / HTTP_PROXY / NO_PROXY (corporate proxies, agent sandboxes)
 * and NODE_EXTRA_CA_CERTS. No dependencies.
 */
export interface HttpResponse {
  status: number;
  headers: http.IncomingHttpHeaders;
  text: string;
  json<T = unknown>(): T;
}

export interface HttpOptions {
  method?: string;
  headers?: Record<string, string>;
  body?: string;
  timeoutMs?: number;
}

function proxyFor(url: URL): URL | undefined {
  const noProxy = (process.env.NO_PROXY ?? process.env.no_proxy ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  const host = url.hostname.toLowerCase();
  for (const rule of noProxy) {
    const r = rule.toLowerCase().replace(/^\*/, "");
    if (r === "*" || host === r || (r.startsWith(".") && host.endsWith(r)) || host.endsWith(`.${r}`)) return undefined;
  }
  const raw = url.protocol === "https:" ? process.env.HTTPS_PROXY ?? process.env.https_proxy : process.env.HTTP_PROXY ?? process.env.http_proxy;
  return raw ? new URL(raw) : undefined;
}

function tunnel(proxy: URL, target: URL, timeoutMs: number): Promise<tls.TLSSocket> {
  return new Promise((resolve, reject) => {
    const port = Number(target.port || 443);
    const req = http.request({
      host: proxy.hostname,
      port: Number(proxy.port || 80),
      method: "CONNECT",
      path: `${target.hostname}:${port}`,
      headers: {
        Host: `${target.hostname}:${port}`,
        ...(proxy.username ? { "Proxy-Authorization": `Basic ${Buffer.from(`${decodeURIComponent(proxy.username)}:${decodeURIComponent(proxy.password)}`).toString("base64")}` } : {}),
      },
      timeout: timeoutMs,
    });
    req.on("connect", (res, socket: net.Socket) => {
      if (res.statusCode !== 200) {
        socket.destroy();
        return reject(new Error(`proxy CONNECT ${target.hostname}:${port} → ${res.statusCode} ${res.statusMessage ?? ""}`.trim()));
      }
      const secure = tls.connect({ socket, servername: target.hostname }, () => resolve(secure));
      secure.on("error", reject);
    });
    req.on("timeout", () => req.destroy(new Error(`proxy CONNECT timeout after ${timeoutMs}ms`)));
    req.on("error", reject);
    req.end();
  });
}

export async function httpRequest(urlStr: string, opts: HttpOptions = {}): Promise<HttpResponse> {
  const url = new URL(urlStr);
  const timeoutMs = opts.timeoutMs ?? 30_000;
  const proxy = proxyFor(url);
  const headers: Record<string, string> = { ...opts.headers };
  if (opts.body !== undefined && !Object.keys(headers).some((h) => h.toLowerCase() === "content-length")) headers["Content-Length"] = String(Buffer.byteLength(opts.body));

  const base: http.RequestOptions = { method: opts.method ?? "GET", host: url.hostname, port: url.port || (url.protocol === "https:" ? 443 : 80), path: `${url.pathname}${url.search}`, headers, timeout: timeoutMs };
  let reqOpts: http.RequestOptions = base;
  let lib: typeof http | typeof https = url.protocol === "https:" ? https : http;
  if (proxy && url.protocol === "https:") {
    const socket = await tunnel(proxy, url, timeoutMs);
    lib = http; // the socket is already TLS; speak plain HTTP over it
    reqOpts = { ...base, createConnection: () => socket }; // no agent → Node uses createConnection
  } else if (proxy) {
    reqOpts = { ...base, host: proxy.hostname, port: Number(proxy.port || 80), path: url.toString() };
  }

  return new Promise((resolve, reject) => {
    const req = lib.request(reqOpts, (res) => {
      const chunks: Buffer[] = [];
      res.on("data", (c: Buffer) => chunks.push(c));
      res.on("end", () => {
        const text = Buffer.concat(chunks).toString("utf8");
        resolve({
          status: res.statusCode ?? 0,
          headers: res.headers,
          text,
          json: <T>() => {
            try {
              return JSON.parse(text) as T;
            } catch {
              throw new Error(`non-JSON response (${res.statusCode}) from ${url.host}: ${text.slice(0, 200)}`);
            }
          },
        });
      });
      res.on("error", reject);
    });
    req.on("timeout", () => req.destroy(new Error(`request to ${url.host} timed out after ${timeoutMs}ms`)));
    req.on("error", reject);
    if (opts.body !== undefined) req.write(opts.body);
    req.end();
  });
}
