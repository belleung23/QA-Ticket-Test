import fs from "node:fs";
import { test as base, expect } from "@playwright/test";
import { loadConfig, resolveEnvironment, storageStatePath, type EnvironmentConfig, type QaConfig } from "../config/load.js";
import { strategyFor } from "../auth/strategies.js";

/**
 * Project-aware Playwright fixtures. Specs import { test, expect } from here.
 *
 *   test("@FRAI-123 @High @regression user can …", async ({ page, env }) => { … });
 *
 * `page` is already authenticated per qa.config.yaml; `env` tells you where you are
 * (and whether it is readOnly — never create/modify data when it is).
 */
type Fixtures = {
  qa: QaConfig;
  envKey: string;
  env: EnvironmentConfig;
};

export const test = base.extend<Fixtures>({
  qa: [async ({}, use) => use(loadConfig()), { scope: "test" }],
  envKey: [async ({ qa }, use) => use(resolveEnvironment(qa).key), { scope: "test" }],
  env: [async ({ qa, envKey }, use) => use(resolveEnvironment(qa, { env: envKey }).env), { scope: "test" }],
  // Override Playwright's built-in storageState option from config rather than a hardcoded path.
  storageState: [
    async ({ qa, envKey, env }, use) => {
      const strategy = strategyFor(qa, env);
      if (strategy === "none") return use(undefined);
      const file = storageStatePath(qa, envKey);
      return use(fs.existsSync(file) ? file : undefined);
    },
    { scope: "test" },
  ],
  baseURL: [async ({ env }, use) => use(env.baseUrl), { scope: "test" }],
});

export { expect };

/** Guard for destructive steps: call at the top of any test that writes data. */
export function assertWritable(env: EnvironmentConfig, envKey: string): void {
  if (env.readOnly) throw new Error(`Environment "${envKey}" is readOnly in qa.config.yaml — this test creates or modifies data and must not run here.`);
}
