/**
 * Local web UI for the kit: `npm run ui` → http://localhost:<ui.port>
 * Zero-dependency HTTP server. All state lives in the repo's files
 * (test-cases/, test-reports/, tests/), so the UI, the CLI and the agent
 * skills always see the same thing.
 */
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import { spawn, type ChildProcess } from "node:child_process";
import { fileURLToPath } from "node:url";
import { Kit } from "../pipeline.js";
import { resolveEnvironment, storageStatePath } from "../config/load.js";
import { RecordingSession } from "../recorder/session.js";
import type { TestCase } from "../report/testcases.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const APP_HTML = [path.join(here, "app.html"), path.join(here, "../../../src/ui/app.html")].find((p) => fs.existsSync(p)) ?? path.join(here, "app.html");

class HttpError extends Error {
  constructor(public status: number, message: string) {
    super(message);
  }
}

interface AgentRun {
  key: string;
  prompt: string;
  proc?: ChildProcess;
  log: string[];
  startedAt: string;
  endedAt?: string;
  exitCode?: number | null;
}

export function createServer(kit: Kit): http.Server {
  let session: RecordingSession | undefined;
  let agentRun: AgentRun | undefined;

  const json = (res: http.ServerResponse, status: number, body: unknown) => {
    res.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
    res.end(JSON.stringify(body));
  };
  const readBody = (req: http.IncomingMessage): Promise<Record<string, unknown>> =>
    new Promise((resolve, reject) => {
      const chunks: Buffer[] = [];
      req.on("data", (c: Buffer) => chunks.push(c));
      req.on("end", () => {
        const text = Buffer.concat(chunks).toString("utf8");
        try {
          resolve(text ? (JSON.parse(text) as Record<string, unknown>) : {});
        } catch {
          reject(new HttpError(400, "invalid JSON body"));
        }
      });
      req.on("error", reject);
    });

  const route = async (req: http.IncomingMessage, res: http.ServerResponse): Promise<void> => {
    const url = new URL(req.url ?? "/", "http://localhost");
    const p = url.pathname;
    const m = req.method ?? "GET";

    if (m === "GET" && (p === "/" || p === "/index.html")) {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" });
      res.end(fs.readFileSync(APP_HTML));
      return;
    }

    // Evidence files (screenshots) — only from inside the repo.
    if (m === "GET" && p.startsWith("/file/")) {
      const rel = decodeURIComponent(p.slice("/file/".length));
      const abs = path.resolve(kit.root, rel);
      if (!abs.startsWith(kit.root + path.sep) || !fs.existsSync(abs) || fs.statSync(abs).isDirectory()) throw new HttpError(404, "not found");
      const ext = path.extname(abs).toLowerCase();
      const type = ext === ".png" ? "image/png" : ext === ".webm" ? "video/webm" : ext === ".md" ? "text/markdown; charset=utf-8" : "application/octet-stream";
      res.writeHead(200, { "Content-Type": type });
      fs.createReadStream(abs).pipe(res);
      return;
    }

    if (m === "GET" && p === "/api/config") {
      const { key, env } = resolveEnvironment(kit.cfg);
      const sessions = Object.fromEntries(Object.keys(kit.cfg.environments).map((k) => [k, fs.existsSync(storageStatePath(kit.cfg, k, kit.root))]));
      return json(res, 200, {
        project: kit.cfg.project,
        tracker: kit.cfg.tracker.kind,
        environments: Object.entries(kit.cfg.environments).map(([k, e]) => ({ key: k, baseUrl: e.baseUrl, readOnly: e.readOnly, hasSession: sessions[k] })),
        defaultEnvironment: key,
        baseUrl: env.baseUrl,
        authStrategy: kit.cfg.auth.strategy,
        agentCommandConfigured: !!kit.cfg.ui.agentCommand,
        states: kit.cfg.tracker.kind === "linear" ? kit.cfg.tracker.linear.states : kit.cfg.tracker.jira.transitions,
      });
    }

    if (m === "GET" && p === "/api/tickets") return json(res, 200, kit.listTickets());

    const tm = /^\/api\/tickets\/([^/]+)(?:\/(.+))?$/.exec(p);
    if (tm) {
      const key = kit.validateKey(decodeURIComponent(tm[1]));
      const sub = tm[2] ?? "";
      if (m === "POST" && sub === "analyze") {
        const b = await readBody(req);
        const r = await kit.analyze(key, { env: typeof b.env === "string" ? b.env : undefined });
        return json(res, 200, { ticket: r.ticket, analysis: r.analysis, files: r.files, manualCreated: r.manualCreated });
      }
      if (m === "GET" && sub === "") {
        const ticket = kit.readTicket(key);
        if (!ticket) throw new HttpError(404, `${key} has not been analyzed yet`);
        const { testCases, preamble } = kit.readManual(key);
        const recordings = Object.fromEntries(testCases.map((t) => [t.n, kit.readRecording(key, t.n)]).filter(([, r]) => r).map(([n, r]) => [n, { actions: (r as { actions: unknown[] }).actions.length, startedAt: (r as { startedAt: string }).startedAt, finalScreenshot: (r as { finalScreenshot?: string }).finalScreenshot }]));
        const specDir = kit.specDir(key);
        const specs = fs.existsSync(specDir) ? fs.readdirSync(specDir).filter((f) => f.endsWith(".spec.ts")).map((f) => kit.rel(path.join(specDir, f))) : [];
        const reportsDir = path.join(kit.root, kit.cfg.paths.reports);
        const reports = fs.existsSync(reportsDir) ? fs.readdirSync(reportsDir).filter((f) => f.startsWith(`${key}_`) && f.endsWith(".md")).sort().reverse().map((f) => kit.rel(path.join(reportsDir, f))) : [];
        const analysisMd = fs.existsSync(path.join(kit.ticketDir(key), "analysis.md")) ? fs.readFileSync(path.join(kit.ticketDir(key), "analysis.md"), "utf8") : "";
        return json(res, 200, { ticket, analysis: kit.readAnalysis(key), analysisMd, testCases, preamble, recordings, specs, reports });
      }
      if (m === "PUT" && sub === "cases") {
        const b = await readBody(req);
        const testCases = b.testCases as TestCase[];
        if (!Array.isArray(testCases)) throw new HttpError(400, "testCases must be an array");
        const file = kit.writeManual(key, testCases, { preamble: typeof b.preamble === "string" ? b.preamble : undefined });
        return json(res, 200, { file, testCases: kit.readManual(key).testCases });
      }
      if (m === "POST" && sub === "scaffold") {
        const b = await readBody(req);
        return json(res, 200, kit.scaffold(key, { force: b.force === true }));
      }
      if (m === "POST" && sub === "report") {
        const b = await readBody(req);
        if (typeof b.tester !== "string" || !b.tester.trim()) throw new HttpError(400, "tester (a person's name) is required");
        const r = kit.report(key, { tester: b.tester, env: typeof b.env === "string" ? b.env : undefined, mode: b.mode === "automation" ? "automation" : "manual", notes: Array.isArray(b.notes) ? (b.notes as string[]) : undefined });
        return json(res, 200, { ...r, comment: fs.readFileSync(path.join(kit.ticketDir(key), "comment.md"), "utf8") });
      }
      if (m === "POST" && sub === "comment") {
        const b = await readBody(req);
        return json(res, 200, await kit.comment(key, typeof b.body === "string" ? b.body : undefined));
      }
      if (m === "GET" && sub === "statuses") return json(res, 200, await kit.listStatuses(key));
      if (m === "POST" && sub === "status") {
        const b = await readBody(req);
        if (typeof b.name !== "string") throw new HttpError(400, "name is required");
        await kit.setStatus(key, b.name);
        return json(res, 200, { ok: true });
      }
      if (m === "GET" && sub === "spec") {
        const specDir = kit.specDir(key);
        const files = fs.existsSync(specDir) ? fs.readdirSync(specDir).filter((f) => f.endsWith(".spec.ts")) : [];
        return json(res, 200, files.map((f) => ({ file: kit.rel(path.join(specDir, f)), content: fs.readFileSync(path.join(specDir, f), "utf8") })));
      }
      throw new HttpError(404, `unknown route ${m} ${p}`);
    }

    /* ---------- recording ---------- */
    if (m === "POST" && p === "/api/record/start") {
      const b = await readBody(req);
      if (session?.isOpen) throw new HttpError(409, "a recording is already running — stop it first");
      const key = kit.validateKey(String(b.key ?? ""));
      const tc = Number(b.tc);
      if (!Number.isInteger(tc) || tc < 1) throw new HttpError(400, "tc must be a positive test-case number");
      session = await RecordingSession.start(kit.cfg, { ticket: key, tc, env: typeof b.env === "string" ? b.env : undefined, mediaDir: kit.mediaDir(key), root: kit.root, startPath: typeof b.startPath === "string" ? b.startPath : undefined, headless: b.headless === true });
      return json(res, 200, { ok: true, env: session.envKey, ...session.status() });
    }
    if (m === "GET" && p === "/api/record/status") return json(res, 200, session ? { ...session.status(), ticket: session.recording.ticket, tc: session.recording.tc } : { open: false, actions: 0, steps: [] });
    if (m === "POST" && p === "/api/record/note") {
      const b = await readBody(req);
      if (!session?.isOpen) throw new HttpError(409, "no recording running");
      await session.note(String(b.text ?? "").trim());
      return json(res, 200, session.status());
    }
    if (m === "POST" && p === "/api/record/screenshot") {
      if (!session?.isOpen) throw new HttpError(409, "no recording running");
      return json(res, 200, { screenshot: await session.screenshot() });
    }
    if (m === "POST" && p === "/api/record/stop") {
      if (!session) throw new HttpError(409, "no recording to stop");
      const { recording, steps } = await session.stop();
      const file = kit.writeRecording(recording.ticket, recording);
      session = undefined;
      return json(res, 200, { file, recording, steps });
    }

    /* ---------- agent run ---------- */
    if (m === "POST" && p === "/api/agent/run") {
      const b = await readBody(req);
      const key = kit.validateKey(String(b.key ?? ""));
      const only = Array.isArray(b.only) && b.only.length ? ` --only ${(b.only as number[]).join(",")}` : "";
      const env = typeof b.env === "string" && b.env ? ` --env=${b.env}` : "";
      const prompt = `/qa-manual-run ${key}${env}${only}`;
      const cmd = kit.cfg.ui.agentCommand;
      if (!cmd) return json(res, 200, { started: false, prompt, hint: "Set ui.agentCommand in qa.config.yaml to launch an agent from here, or paste this command into your agent." });
      if (agentRun?.proc && agentRun.exitCode === undefined) throw new HttpError(409, "an agent run is already in progress");
      const full = cmd.replace("{prompt}", prompt.replace(/"/g, '\\"'));
      const run: AgentRun = { key, prompt, log: [`$ ${full}`], startedAt: new Date().toISOString() };
      const proc = spawn(full, { cwd: kit.root, shell: true, env: process.env });
      run.proc = proc;
      proc.stdout.on("data", (d: Buffer) => run.log.push(d.toString()));
      proc.stderr.on("data", (d: Buffer) => run.log.push(d.toString()));
      proc.on("close", (code) => {
        run.exitCode = code;
        run.endedAt = new Date().toISOString();
      });
      agentRun = run;
      return json(res, 200, { started: true, prompt });
    }
    if (m === "GET" && p === "/api/agent/status") {
      if (!agentRun) return json(res, 200, { running: false });
      const r = agentRun;
      return json(res, 200, { running: r.exitCode === undefined, key: r.key, prompt: r.prompt, startedAt: r.startedAt, endedAt: r.endedAt, exitCode: r.exitCode, log: r.log.join("").slice(-20000) });
    }
    if (m === "POST" && p === "/api/agent/stop") {
      agentRun?.proc?.kill("SIGTERM");
      return json(res, 200, { ok: true });
    }

    throw new HttpError(404, `unknown route ${m} ${p}`);
  };

  return http.createServer((req, res) => {
    route(req, res).catch((e: unknown) => {
      const err = e as HttpError;
      const status = typeof err.status === "number" ? err.status : 500;
      if (status >= 500) console.error(err);
      json(res, status, { error: err.message ?? String(e) });
    });
  });
}

export function startUi(opts: { port?: number } = {}): http.Server {
  const kit = new Kit();
  const port = opts.port ?? kit.cfg.ui.port;
  const server = createServer(kit);
  server.listen(port, "127.0.0.1", () => {
    console.log(`ticket-qa-kit UI → http://localhost:${port}   (project: ${kit.cfg.project.name}, tracker: ${kit.cfg.tracker.kind})`);
  });
  return server;
}
