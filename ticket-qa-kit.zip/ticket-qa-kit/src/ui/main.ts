#!/usr/bin/env node
import { startUi } from "./server.js";

const portArg = process.argv.find((a) => a.startsWith("--port="));
startUi({ port: portArg ? Number(portArg.split("=")[1]) : undefined });
