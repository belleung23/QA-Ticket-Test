/**
 * Script injected into every page of the recording browser. It watches what the
 * tester does and reports each action through the `__tqaRecord` binding with the
 * best locator it can find, in Playwright's order of preference:
 *   data-testid → role + accessible name → label → placeholder → unique text → CSS
 * Kept as a string so it needs no bundler; it must stay self-contained ES2020.
 */
export const RECORDER_SCRIPT = String.raw`
(() => {
  // Guard per document, not per window: a window can get a new document (about:blank → content).
  if (document.__tqaInstalled) return;
  document.__tqaInstalled = true;
  window.__tqaInstalled = true;
  const send = (a) => { try { window.__tqaRecord(a); } catch (e) { console.error("tqa recorder: binding call failed", e); } };
  const guard = (fn) => (ev) => { try { fn(ev); } catch (e) { console.error("tqa recorder:", e && e.stack || e); } };
  const clean = (s) => (s || "").replace(/\s+/g, " ").trim();
  const short = (s, n = 80) => (s.length > n ? s.slice(0, n) : s);

  const TESTID_ATTRS = ["data-testid", "data-test-id", "data-test", "data-cy", "data-qa"];
  const INTERACTIVE = 'button, a[href], input, select, textarea, label, summary, [role="button"], [role="link"], [role="tab"], [role="menuitem"], [role="option"], [role="checkbox"], [role="radio"], [role="switch"], [role="combobox"], [contenteditable="true"], [onclick], [tabindex]:not([tabindex="-1"])';

  function roleOf(el) {
    const r = el.getAttribute("role");
    if (r) return r.split(/\s+/)[0];
    const t = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (t === "button" || (t === "input" && ["button", "submit", "reset", "image"].includes(type))) return "button";
    if (t === "a" && el.hasAttribute("href")) return "link";
    if (t === "input") {
      if (type === "checkbox") return "checkbox";
      if (type === "radio") return "radio";
      if (["range"].includes(type)) return "slider";
      if (["number"].includes(type)) return "spinbutton";
      if (["search"].includes(type)) return "searchbox";
      if (["hidden", "file", "color", "date", "datetime-local", "month", "time", "week"].includes(type)) return "";
      return "textbox";
    }
    if (t === "textarea") return "textbox";
    if (t === "select") return el.multiple ? "listbox" : "combobox";
    if (t === "option") return "option";
    if (/^h[1-6]$/.test(t)) return "heading";
    if (t === "img") return "img";
    if (t === "li") return "listitem";
    if (t === "summary") return "button";
    if (t === "dialog") return "dialog";
    return "";
  }

  function labelTextFor(el) {
    if (el.id) {
      const lab = document.querySelector('label[for="' + CSS.escape(el.id) + '"]');
      if (lab) return clean(lab.textContent);
    }
    const wrap = el.closest("label");
    if (wrap) return clean(wrap.textContent);
    const lb = el.getAttribute("aria-labelledby");
    if (lb) return clean(lb.split(/\s+/).map((id) => (document.getElementById(id) || {}).textContent || "").join(" "));
    return "";
  }

  function accessibleName(el) {
    const al = el.getAttribute("aria-label");
    if (al) return clean(al);
    const lb = labelTextFor(el);
    if (lb) return lb;
    const t = el.tagName.toLowerCase();
    if (t === "img") return clean(el.getAttribute("alt"));
    if (t === "input" && ["button", "submit", "reset"].includes((el.type || "").toLowerCase())) return clean(el.value);
    const text = clean(el.innerText || el.textContent);
    if (text) return short(text);
    return clean(el.getAttribute("title"));
  }

  function countBy(pred) {
    let n = 0;
    const all = document.querySelectorAll("*");
    for (const e of all) { if (pred(e)) { n++; if (n > 1) break; } }
    return n;
  }

  function cssPath(el) {
    if (el.id && !/\d{3,}/.test(el.id)) return "#" + CSS.escape(el.id);
    const parts = [];
    let cur = el;
    while (cur && cur.nodeType === 1 && parts.length < 6) {
      let sel = cur.tagName.toLowerCase();
      if (cur.id && !/\d{3,}/.test(cur.id)) { parts.unshift("#" + CSS.escape(cur.id)); break; }
      const parent = cur.parentElement;
      if (parent) {
        const same = Array.from(parent.children).filter((c) => c.tagName === cur.tagName);
        if (same.length > 1) sel += ":nth-of-type(" + (same.indexOf(cur) + 1) + ")";
      }
      parts.unshift(sel);
      cur = parent;
    }
    return parts.join(" > ");
  }

  function locatorFor(el) {
    for (const a of TESTID_ATTRS) {
      const v = el.getAttribute(a);
      if (v) return { method: "getByTestId", value: v };
    }
    const role = roleOf(el);
    const name = accessibleName(el);
    if (role && name) {
      const c = countBy((e) => roleOf(e) === role && accessibleName(e) === name);
      if (c === 1) return { method: "getByRole", role, name, exact: true };
    }
    const lab = labelTextFor(el);
    if (lab && countBy((e) => /^(input|select|textarea)$/i.test(e.tagName) && labelTextFor(e) === lab) === 1) return { method: "getByLabel", value: lab, exact: true };
    const ph = el.getAttribute("placeholder");
    if (ph && countBy((e) => e.getAttribute && e.getAttribute("placeholder") === ph) === 1) return { method: "getByPlaceholder", value: ph, exact: true };
    const text = clean(el.innerText || el.textContent);
    if (text && text.length <= 60 && countBy((e) => clean(e.innerText || e.textContent) === text && e.children.length === 0) === 1) return { method: "getByText", value: text, exact: true };
    if (role && name) return { method: "getByRole", role, name, exact: true }; // not unique, but still the most readable; Playwright will report strictness
    return { method: "locator", value: cssPath(el) };
  }

  function target(ev) {
    let el = ev.target;
    if (!(el instanceof Element)) return null;
    const inter = el.closest(INTERACTIVE);
    return inter || el;
  }

  const t0 = performance.now();
  const now = () => Math.round(performance.now() - t0);
  const pendingFill = new Map();

  function flushFill(el) {
    if (!pendingFill.has(el)) return;
    pendingFill.delete(el);
    const t = el.tagName.toLowerCase();
    if (t === "select") return;
    const value = el.isContentEditable ? clean(el.innerText) : el.value;
    send({ kind: "fill", at: now(), locator: locatorFor(el), value, label: accessibleName(el) || el.getAttribute("placeholder") || "" });
  }

  document.addEventListener("click", guard((ev) => {
    const el = target(ev);
    if (!el) return;
    const t = el.tagName.toLowerCase();
    const type = (el.getAttribute("type") || "").toLowerCase();
    if (t === "input" && (type === "checkbox" || type === "radio")) {
      send({ kind: el.checked ? "check" : "uncheck", at: now(), locator: locatorFor(el), label: accessibleName(el) });
      return;
    }
    if (t === "input" || t === "textarea" || t === "select" || el.isContentEditable) return; // focus, not an action
    send({ kind: "click", at: now(), locator: locatorFor(el), label: accessibleName(el) || t });
  }), true);

  document.addEventListener("input", guard((ev) => {
    const el = ev.target;
    if (!(el instanceof Element)) return;
    const type = (el.getAttribute("type") || "text").toLowerCase();
    const textLike = el.tagName.toLowerCase() === "textarea" || el.isContentEditable || (el.tagName.toLowerCase() === "input" && !["checkbox", "radio", "button", "submit", "reset", "file", "range", "color"].includes(type));
    if (textLike) pendingFill.set(el, true);
  }), true);

  document.addEventListener("change", guard((ev) => {
    const el = ev.target;
    if (!(el instanceof Element)) return;
    if (el.tagName.toLowerCase() === "select") {
      const opt = el.options[el.selectedIndex];
      send({ kind: "select", at: now(), locator: locatorFor(el), value: opt ? clean(opt.textContent) : el.value, label: accessibleName(el) });
      return;
    }
    flushFill(el);
  }), true);

  document.addEventListener("blur", guard((ev) => { if (ev.target instanceof Element) flushFill(ev.target); }), true);

  document.addEventListener("keydown", guard((ev) => {
    if (!["Enter", "Escape", "Tab"].includes(ev.key)) return;
    const el = ev.target instanceof Element ? ev.target : document.activeElement;
    if (!el) return;
    flushFill(el);
    send({ kind: "press", at: now(), locator: locatorFor(el), value: ev.key, label: accessibleName(el) || el.getAttribute("placeholder") || el.tagName.toLowerCase() });
  }), true);
})();
`;
