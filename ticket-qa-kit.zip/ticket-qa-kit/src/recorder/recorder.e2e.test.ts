// Headless end-to-end test of the in-page recorder + codegen. Needs a Playwright
// browser installed (npx playwright install chromium). Run: npm run selftest:recorder
import { test } from "node:test";
import assert from "node:assert/strict";
import { chromium } from "@playwright/test";
import { RECORDER_SCRIPT } from "./inject.js";
import { actionsToSteps } from "./codegen.js";
import type { RecordedAction, Recording } from "./types.js";

const FIXTURE = `<!doctype html><html><body>
  <h1>Settings</h1>
  <label for="email">Email</label><input id="email" type="email" placeholder="you@example.com">
  <input type="text" placeholder="Search policies">
  <label><input type="checkbox" id="remember"> Remember me</label>
  <label for="role">Role</label><select id="role"><option>Viewer</option><option>Editor</option></select>
  <button data-testid="save-btn">Save</button>
  <button>Cancel</button><button>Cancel</button>
  <a href="#next" id="next-link">Next page</a>
  <div class="card"><span>Plain text cell</span></div>
</body></html>`;

test("recorder captures clicks, fills, checks, selects, keys with Playwright-style locators", async () => {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const actions: RecordedAction[] = [];
  await context.exposeBinding("__tqaRecord", (_s, a: RecordedAction) => {
    actions.push(a);
  });
  await context.addInitScript(RECORDER_SCRIPT);
  const page = await context.newPage();
  // A real navigation (not setContent — document.open() drops the init script's listeners).
  await context.route("https://fixture.local/**", (r) => r.fulfill({ contentType: "text/html", body: FIXTURE }));
  await page.goto("https://fixture.local/settings");

  await page.getByLabel("Email").fill("qa@example.com");
  await page.getByPlaceholder("Search policies").fill("dlp");
  await page.getByPlaceholder("Search policies").press("Enter");
  await page.getByLabel("Remember me").check();
  await page.getByLabel("Role").selectOption("Editor");
  await page.getByTestId("save-btn").click();
  await page.getByRole("button", { name: "Cancel" }).first().click();
  await page.getByRole("link", { name: "Next page" }).click();
  await page.getByText("Plain text cell").click();
  await page.waitForTimeout(100);
  await browser.close();

  const kinds = actions.map((a) => a.kind);
  assert.deepEqual(kinds, ["fill", "fill", "press", "check", "select", "click", "click", "click", "click"], JSON.stringify(actions, null, 1));
  assert.deepEqual(actions[0].locator, { method: "getByRole", role: "textbox", name: "Email", exact: true });
  assert.equal(actions[0].value, "qa@example.com");
  assert.deepEqual(actions[1].locator, { method: "getByPlaceholder", value: "Search policies", exact: true });
  assert.equal(actions[2].value, "Enter");
  assert.deepEqual(actions[3].locator, { method: "getByRole", role: "checkbox", name: "Remember me", exact: true });
  assert.equal(actions[4].value, "Editor");
  assert.deepEqual(actions[5].locator, { method: "getByTestId", value: "save-btn" });
  // two "Cancel" buttons → role+name is not unique; recorder must not claim uniqueness via text either
  assert.notEqual(actions[6].locator?.method, "getByText");
  assert.deepEqual(actions[7].locator, { method: "getByRole", role: "link", name: "Next page", exact: true });
  assert.deepEqual(actions[8].locator, { method: "getByText", value: "Plain text cell", exact: true });

  const rec: Recording = { ticket: "DEMO-1", tc: 1, envKey: "dev", baseUrl: "https://app.example.com", startedAt: "", actions: [{ kind: "navigated", at: 0, value: "https://app.example.com/settings" }, ...actions, { kind: "navigated", at: 0, value: "https://app.example.com/settings#next" }, { kind: "note", at: 0, value: "toast says Saved" }] };
  const steps = actionsToSteps(rec);
  assert.equal(steps[0].text, "Open /settings");
  assert.equal(steps[0].code[0], 'await page.goto("/settings");');
  assert.match(steps[1].text, /^Fill the "Email" textbox with "qa@example.com"$/);
  assert.equal(steps[1].code[0], 'await page.getByRole("textbox", { name: "Email", exact: true }).fill("qa@example.com");');
  assert.equal(steps[6].code[0], 'await page.getByTestId("save-btn").click();');
  const landed = steps.find((s) => /lands on/.test(s.text));
  assert.ok(landed && landed.code.some((c) => c.includes("toHaveURL")), "navigation after a click becomes a URL assertion");
  assert.match(steps[steps.length - 1].text, /^Verify: toast says Saved/);
  assert.doesNotMatch(JSON.stringify(steps), /https?:\/\//, "generated code must not contain absolute URLs");
});
