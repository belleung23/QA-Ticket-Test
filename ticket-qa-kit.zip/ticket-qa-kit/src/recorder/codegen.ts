import type { Locator, RecordedAction, RecordedStep, Recording } from "./types.js";

const q = (s: string) => JSON.stringify(s);

export function locatorCode(l: Locator): string {
  switch (l.method) {
    case "getByTestId":
      return `page.getByTestId(${q(l.value)})`;
    case "getByRole":
      return `page.getByRole(${q(l.role)}${l.name ? `, { name: ${q(l.name)}${l.exact ? ", exact: true" : ""} }` : ""})`;
    case "getByLabel":
      return `page.getByLabel(${q(l.value)}${l.exact ? ", { exact: true }" : ""})`;
    case "getByPlaceholder":
      return `page.getByPlaceholder(${q(l.value)}${l.exact ? ", { exact: true }" : ""})`;
    case "getByText":
      return `page.getByText(${q(l.value)}${l.exact ? ", { exact: true }" : ""})`;
    case "locator":
      return `page.locator(${q(l.value)})`;
  }
}

function describeTarget(a: RecordedAction): string {
  const l = a.locator;
  const label = a.label?.trim();
  if (l?.method === "getByRole") return `the "${l.name ?? label ?? ""}" ${l.role}`;
  if (l?.method === "getByLabel") return `the "${l.value}" field`;
  if (l?.method === "getByPlaceholder") return `the "${l.value}" field`;
  if (l?.method === "getByTestId") return label ? `"${label}" (${l.value})` : `the "${l.value}" element`;
  if (l?.method === "getByText") return `"${l.value}"`;
  return label ? `"${label}"` : "the element";
}

function relPath(url: string, baseUrl: string): string {
  try {
    const u = new URL(url);
    const b = new URL(baseUrl);
    return u.origin === b.origin ? `${u.pathname}${u.search}` : url;
  } catch {
    return url;
  }
}

/**
 * Turn raw recorded actions into numbered steps. Consecutive navigations caused
 * by a click become a URL assertion on that step instead of a goto.
 */
export function actionsToSteps(rec: Recording): RecordedStep[] {
  const steps: RecordedStep[] = [];
  let first = true;
  for (const a of rec.actions) {
    const loc = a.locator ? locatorCode(a.locator) : "page";
    switch (a.kind) {
      case "goto":
        steps.push({ text: `Open ${relPath(a.value ?? "", rec.baseUrl)}`, code: [`await page.goto(${q(relPath(a.value ?? "/", rec.baseUrl))});`], screenshot: a.screenshot });
        first = false;
        break;
      case "navigated": {
        const path = relPath(a.value ?? "", rec.baseUrl);
        if (first || steps.length === 0) {
          steps.push({ text: `Open ${path}`, code: [`await page.goto(${q(path)});`], screenshot: a.screenshot });
        } else {
          const last = steps[steps.length - 1];
          last.text += ` → lands on ${path}`;
          last.code.push(`await expect(page).toHaveURL(${q(path)});`);
          if (a.screenshot) last.screenshot = a.screenshot;
        }
        first = false;
        break;
      }
      case "click":
        steps.push({ text: `Click ${describeTarget(a)}`, code: [`await ${loc}.click();`], screenshot: a.screenshot });
        break;
      case "fill":
        steps.push({ text: `Fill ${describeTarget(a)} with "${a.value ?? ""}"`, code: [`await ${loc}.fill(${q(a.value ?? "")});`], screenshot: a.screenshot });
        break;
      case "check":
        steps.push({ text: `Check ${describeTarget(a)}`, code: [`await ${loc}.check();`], screenshot: a.screenshot });
        break;
      case "uncheck":
        steps.push({ text: `Uncheck ${describeTarget(a)}`, code: [`await ${loc}.uncheck();`], screenshot: a.screenshot });
        break;
      case "select":
        steps.push({ text: `Select "${a.value ?? ""}" in ${describeTarget(a)}`, code: [`await ${loc}.selectOption({ label: ${q(a.value ?? "")} });`], screenshot: a.screenshot });
        break;
      case "press":
        steps.push({ text: `Press ${a.value} in ${describeTarget(a)}`, code: [`await ${loc}.press(${q(a.value ?? "Enter")});`], screenshot: a.screenshot });
        break;
      case "note":
        steps.push({ text: `Verify: ${a.value ?? ""}`, code: [`// TODO assert: ${a.value ?? ""}`, `// e.g. await expect(page.getByText(${q(a.value ?? "")})).toBeVisible();`], screenshot: a.screenshot });
        break;
      case "screenshot":
        if (steps.length) steps[steps.length - 1].screenshot = a.screenshot;
        else steps.push({ text: "Observe the page", code: [], screenshot: a.screenshot });
        break;
    }
    first = false;
  }
  return steps;
}
