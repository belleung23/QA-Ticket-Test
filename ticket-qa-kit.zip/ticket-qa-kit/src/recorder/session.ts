import fs from "node:fs";
import path from "node:path";
import { chromium, firefox, webkit, type Browser, type BrowserContext, type Page } from "@playwright/test";
import { resolveEnvironment, type QaConfig } from "../config/load.js";
import { authenticatedContext, makeAuthContext } from "../auth/strategies.js";
import { RECORDER_SCRIPT } from "./inject.js";
import { actionsToSteps } from "./codegen.js";
import type { RecordedAction, RecordedStep, Recording } from "./types.js";

export interface SessionOptions {
  ticket: string;
  tc: number;
  env?: string;
  headless?: boolean; // tests only
  /** absolute dir for screenshots; relative paths in the recording are computed against `root` */
  mediaDir: string;
  root: string;
  /** optional path to open first (relative to baseUrl); defaults to "/" */
  startPath?: string;
}

/**
 * One recording at a time. The tester drives the browser by hand; every action
 * arrives through the `__tqaRecord` binding and gets a screenshot.
 */
export class RecordingSession {
  private browser?: Browser;
  private context?: BrowserContext;
  private page?: Page;
  private t0 = Date.now();
  private shots = 0;
  private closed = false;
  readonly recording: Recording;
  readonly envKey: string;
  private onClose?: () => void;

  private constructor(private readonly cfg: QaConfig, private readonly opts: SessionOptions) {
    const { key, env } = resolveEnvironment(cfg, { env: opts.env });
    this.envKey = key;
    this.recording = { ticket: opts.ticket, tc: opts.tc, envKey: key, baseUrl: env.baseUrl, startedAt: new Date().toISOString(), actions: [] };
  }

  static async start(cfg: QaConfig, opts: SessionOptions): Promise<RecordingSession> {
    const s = new RecordingSession(cfg, opts);
    await s.launch();
    return s;
  }

  private async launch(): Promise<void> {
    const { key, env } = resolveEnvironment(this.cfg, { env: this.opts.env });
    const launcher = { chromium, firefox, webkit }[this.cfg.playwright.browser];
    this.browser = await launcher.launch({ headless: this.opts.headless ?? false });
    this.context = await authenticatedContext(this.browser, makeAuthContext(this.cfg, key, env));
    await this.context.exposeBinding("__tqaRecord", async (_src, action: RecordedAction) => this.onAction(action));
    await this.context.addInitScript(RECORDER_SCRIPT);
    this.page = await this.context.newPage();
    this.page.on("framenavigated", (frame) => {
      if (frame !== this.page?.mainFrame()) return;
      const url = frame.url();
      if (!url || url === "about:blank") return;
      void this.onAction({ kind: "navigated", at: Date.now() - this.t0, value: url });
    });
    this.context.on("close", () => {
      this.closed = true;
      this.onClose?.();
    });
    this.t0 = Date.now();
    await this.page.goto(new URL(this.opts.startPath ?? "/", env.baseUrl).toString());
  }

  private async onAction(action: RecordedAction): Promise<void> {
    if (this.closed) return;
    action.at = Date.now() - this.t0;
    // Collapse the navigation that immediately follows a page.goto() we issued ourselves.
    const prev = this.recording.actions[this.recording.actions.length - 1];
    if (action.kind === "navigated" && prev?.kind === "navigated" && prev.value === action.value) return;
    this.recording.actions.push(action);
    await this.snap(action);
  }

  private async snap(action: RecordedAction): Promise<void> {
    if (!this.page || this.closed) return;
    try {
      await this.page.waitForLoadState("domcontentloaded", { timeout: 2000 }).catch(() => undefined);
      await this.page.waitForTimeout(150); // let the UI settle after the action (recording only, never in specs)
      const file = path.join(this.opts.mediaDir, `TC${this.opts.tc}_rec${String(++this.shots).padStart(2, "0")}_${action.kind}.png`);
      fs.mkdirSync(this.opts.mediaDir, { recursive: true });
      await this.page.screenshot({ path: file, fullPage: false });
      action.screenshot = path.relative(this.opts.root, file).split(path.sep).join("/");
    } catch {
      /* page navigating or closed — skip the shot */
    }
  }

  /** The tester notes an expected outcome they just observed ("toast says Saved"). */
  async note(text: string): Promise<void> {
    await this.onAction({ kind: "note", at: 0, value: text });
  }

  /** Evidence on demand. */
  async screenshot(): Promise<string | undefined> {
    const a: RecordedAction = { kind: "screenshot", at: 0 };
    await this.onAction(a);
    return a.screenshot;
  }

  get isOpen(): boolean {
    return !this.closed;
  }

  whenClosed(cb: () => void): void {
    this.onClose = cb;
  }

  status(): { open: boolean; actions: number; steps: RecordedStep[]; url?: string } {
    return { open: !this.closed, actions: this.recording.actions.length, steps: actionsToSteps(this.recording), url: this.page?.url() };
  }

  async stop(): Promise<{ recording: Recording; steps: RecordedStep[] }> {
    if (!this.closed && this.page) {
      try {
        this.recording.finalUrl = this.page.url();
        const file = path.join(this.opts.mediaDir, `TC${this.opts.tc}_final.png`);
        await this.page.screenshot({ path: file, fullPage: true });
        this.recording.finalScreenshot = path.relative(this.opts.root, file).split(path.sep).join("/");
      } catch {
        /* ignore */
      }
    }
    this.closed = true;
    this.recording.endedAt = new Date().toISOString();
    await this.browser?.close().catch(() => undefined);
    return { recording: this.recording, steps: actionsToSteps(this.recording) };
  }
}
