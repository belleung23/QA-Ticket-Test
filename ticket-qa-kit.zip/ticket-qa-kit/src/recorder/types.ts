/** A locator the way Playwright would write it, chosen by the in-page recorder. */
export type Locator =
  | { method: "getByTestId"; value: string }
  | { method: "getByRole"; role: string; name?: string; exact?: boolean }
  | { method: "getByLabel"; value: string; exact?: boolean }
  | { method: "getByPlaceholder"; value: string; exact?: boolean }
  | { method: "getByText"; value: string; exact?: boolean }
  | { method: "locator"; value: string };

export type ActionKind = "goto" | "click" | "fill" | "check" | "uncheck" | "select" | "press" | "navigated" | "note" | "screenshot";

export interface RecordedAction {
  kind: ActionKind;
  at: number; // ms since recording start
  locator?: Locator;
  /** fill value, select option label, key name, note text, or URL for goto/navigated */
  value?: string;
  /** what the user-facing label of the element was (for the human step) */
  label?: string;
  /** relative path of a screenshot taken right after the action */
  screenshot?: string;
}

export interface Recording {
  ticket: string;
  tc: number;
  envKey: string;
  baseUrl: string;
  startedAt: string;
  endedAt?: string;
  actions: RecordedAction[];
  finalUrl?: string;
  finalScreenshot?: string;
}

export interface RecordedStep {
  /** human-readable step for manual.md */
  text: string;
  /** Playwright lines for the spec */
  code: string[];
  screenshot?: string;
}
