import type { QaConfig } from "../config/schema.js";
import type { TestCase } from "../report/testcases.js";
import type { Recording } from "../recorder/types.js";
import { actionsToSteps } from "../recorder/codegen.js";

export function slugify(s: string): string {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "test";
}

/**
 * Turn approved manual test cases (Automate = yes) into a Playwright spec SKELETON.
 * Each manual step becomes a `test.step` with a TODO; the expected result becomes a
 * TODO assertion. The agent (or a human) then replaces TODOs with real locators and
 * assertions — the skeleton guarantees the spec mirrors the manual case 1:1 and
 * stays traceable through the @<TICKET> and TC tags.
 */
export function scaffoldSpec(opts: { ticketKey: string; ticketTitle: string; testCases: TestCase[]; cfg: QaConfig; importPath?: string; recordings?: Record<number, Recording> }): string {
  const { ticketKey, ticketTitle, cfg } = opts;
  const t = cfg.playwright.tagPrefix;
  const importPath = opts.importPath ?? "../../src/fixtures/test.js";
  const cases = opts.testCases.filter((tc) => tc.automate === "yes");
  const L: string[] = [];
  L.push(`import { test, expect, assertWritable } from "${importPath}";`, "");
  L.push(`/**`, ` * ${ticketKey} — ${ticketTitle}`, ` * Generated from test-cases/${ticketKey}/manual.md (Automate = yes rows).`, ` * Each test mirrors one approved manual case; keep the TC number in the title so`, ` * reports, the manual file and this spec stay in sync.`, ` */`, "");
  L.push(`test.describe("${ticketKey} ${esc(ticketTitle)}", () => {`);
  for (const tc of cases) {
    const tags = [`${t}${ticketKey}`, `${t}TC${tc.n}`, `${t}${tc.priority}`, `${t}${slugify(tc.type)}`, `${t}regression`].join(" ");
    const writes = /\b(create|add|delete|remove|update|edit|save|submit|upload|change)\b/i.test(tc.description + " " + tc.steps.join(" "));
    L.push(`  test("TC${tc.n} ${esc(tc.description)} ${tags}", async ({ page${writes ? ", env, envKey" : ""} }) => {`);
    if (writes) L.push(`    assertWritable(env, envKey); // this case modifies data — refuses to run on readOnly environments`);
    L.push(`    // AC: ${tc.ac || "—"}`);
    const rec = opts.recordings?.[tc.n];
    if (rec) {
      // Recorded by hand in the kit's UI: real locators, real routes. Review, don't trust blindly.
      L.push(`    // Recorded ${rec.startedAt.slice(0, 10)} on "${rec.envKey}" — ${rec.actions.length} actions`);
      for (const [i, st] of actionsToSteps(rec).entries()) {
        L.push(`    await test.step(${JSON.stringify(`${i + 1}. ${st.text}`)}, async () => {`);
        for (const line of st.code) L.push(`      ${line}`);
        if (!st.code.length) L.push(`      // (observation only)`);
        L.push(`    });`);
      }
    } else {
      tc.steps.forEach((step, i) => {
        L.push(`    await test.step(${JSON.stringify(`${i + 1}. ${step}`)}, async () => {`);
        L.push(`      // TODO: implement — ${esc(step)}`);
        if (i === 0 && /\b(open|go to|navigate|visit|login|log in)\b/i.test(step)) L.push(`      await page.goto("/"); // replace with the route from the manual step`);
        L.push(`    });`);
      });
    }
    L.push(`    await test.step("Expected: ${esc(tc.expected)}", async () => {`);
    L.push(`      // TODO: assert the observable outcome — must be able to FAIL if the feature regresses`);
    L.push(`      // e.g. await expect(page.getByRole("alert")).toHaveText(/saved/i);`);
    L.push(`      expect(true, "replace this placeholder with a real assertion").toBe(true);`);
    L.push(`    });`);
    L.push(`  });`, "");
  }
  if (cases.length === 0) L.push(`  test.skip("no manual test cases are marked Automate = yes in manual.md", () => {});`);
  L.push(`});`, "");
  return L.join("\n");
}

const esc = (s: string) => s.replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n+/g, " ");
