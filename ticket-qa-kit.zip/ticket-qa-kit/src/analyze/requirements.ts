import type { QaConfig } from "../config/schema.js";
import type { Ticket } from "../trackers/types.js";

export interface Requirement {
  id: string; // AC1, AC2 …
  text: string;
  source: "heading-section" | "checkbox" | "gherkin" | "ac-label" | "ac-field" | "comment" | "fallback";
  /** words from analysis.vagueWords found in the text */
  vague: string[];
}

export interface Analysis {
  ticket: Pick<Ticket, "key" | "title" | "url" | "status" | "type" | "priority" | "labels" | "pullRequests">;
  requirements: Requirement[];
  /** Questions the agent should ask the ticket author before testing */
  clarifications: string[];
  /** Things mentioned that are explicitly out of scope */
  outOfScope: string[];
  /** Preconditions / test data hints found in the text */
  preconditions: string[];
  /** Raw sections by heading, for the agent to read the full context */
  sections: Array<{ heading: string; body: string }>;
}

const CHECKBOX_RE = /^\s*[-*]\s*\[( |x|X)\]\s+(.*)$/;
const BULLET_RE = /^\s*(?:[-*+]|\d+[.)])\s+(.*)$/;
const AC_LABEL_RE = /^\s*(?:AC|A\.C\.|Acceptance Criteri(?:a|on))\s*#?\s*(\d+)?\s*[:.)-]\s*(.*)$/i;
const GHERKIN_RE = /^\s*(Given|When|Then|And|But)\b/i;

export function splitSections(md: string): Array<{ heading: string; body: string }> {
  const lines = md.replace(/\r\n/g, "\n").split("\n");
  const out: Array<{ heading: string; body: string[] }> = [{ heading: "", body: [] }];
  for (const line of lines) {
    const h = /^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$/.exec(line) ?? /^\s*\*\*([^*]{2,60})\*\*\s*:?\s*$/.exec(line);
    if (h) out.push({ heading: h[1].trim(), body: [] });
    else out[out.length - 1].body.push(line);
  }
  return out.map((s) => ({ heading: s.heading, body: s.body.join("\n").trim() })).filter((s) => s.heading || s.body);
}

function findVague(text: string, vagueWords: string[]): string[] {
  const lower = text.toLowerCase();
  return vagueWords.filter((w) => new RegExp(`\\b${w.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`).test(lower));
}

function collectItems(body: string): string[] {
  const items: string[] = [];
  let gherkin: string[] = [];
  const flush = () => {
    if (gherkin.length) items.push(gherkin.join(" "));
    gherkin = [];
  };
  for (const raw of body.split("\n")) {
    const line = raw.trimEnd();
    if (!line.trim()) {
      flush();
      continue;
    }
    const cb = CHECKBOX_RE.exec(line);
    if (cb) {
      flush();
      items.push(cb[2].trim());
      continue;
    }
    if (GHERKIN_RE.test(line.replace(BULLET_RE, "$1"))) {
      gherkin.push(line.replace(BULLET_RE, "$1").trim());
      continue;
    }
    const b = BULLET_RE.exec(line);
    if (b) {
      flush();
      items.push(b[1].trim());
      continue;
    }
    flush();
    // A sentence-y paragraph under a requirements heading still counts.
    if (line.trim().length > 15) items.push(line.trim());
  }
  flush();
  return items.filter((t) => t && !/^[-=_]{3,}$/.test(t));
}

export function analyzeTicket(ticket: Ticket, cfg: QaConfig): Analysis {
  const { requirementHeadings, vagueWords } = cfg.analysis;
  const headingRes = requirementHeadings.map((h) => new RegExp(h, "i"));
  const sections = splitSections(ticket.description);
  const reqs: Array<Omit<Requirement, "id"> & { label?: string }> = [];
  const LABEL_RE = /^\s*(?:AC|A\.C\.|Acceptance Criteri(?:a|on))\s*#?\s*(\d+[a-z]?)\s*[:.)-]\s*/i;
  const outOfScope: string[] = [];
  const preconditions: string[] = [];
  const push = (text: string, source: Requirement["source"]) => {
    let clean = text.replace(/\s+/g, " ").trim();
    // Keep the author's own numbering ("AC4b: …") as the id instead of double-prefixing.
    const m = LABEL_RE.exec(clean);
    const label = m ? `AC${m[1].toUpperCase()}` : undefined;
    if (m) clean = clean.slice(m[0].length).trim();
    if (clean && !reqs.some((r) => r.text.toLowerCase() === clean.toLowerCase())) reqs.push({ text: clean, source, vague: findVague(clean, vagueWords), label });
  };

  // 1. Dedicated AC field (Jira custom field)
  if (ticket.acceptanceCriteriaField) for (const t of collectItems(ticket.acceptanceCriteriaField)) push(t, "ac-field");

  // 2. Sections whose heading looks like requirements / scope / DoD
  for (const s of sections) {
    const head = s.heading.toLowerCase();
    if (/out of scope|non-goals?|not in scope/.test(head)) {
      outOfScope.push(...collectItems(s.body));
      continue;
    }
    if (/pre-?conditions?|prerequisites?|test data|setup/.test(head)) {
      preconditions.push(...collectItems(s.body));
      continue;
    }
    if (headingRes.some((re) => re.test(s.heading))) for (const t of collectItems(s.body)) push(t, "heading-section");
  }

  // 3. Anywhere: "AC1: …" labels, checkboxes, Gherkin blocks
  for (const line of ticket.description.split("\n")) {
    const ac = AC_LABEL_RE.exec(line);
    if (ac) push(ac[2], "ac-label");
    const cb = CHECKBOX_RE.exec(line);
    if (cb && reqs.length === 0) push(cb[2], "checkbox");
  }
  if (reqs.length === 0) {
    const gh = collectItems(ticket.description).filter((t) => GHERKIN_RE.test(t));
    for (const t of gh) push(t, "gherkin");
  }

  // 4. Fallback: description paragraphs → one requirement per sentence-ish line
  if (reqs.length === 0) for (const t of collectItems(ticket.description)) push(t, "fallback");

  // 5. Requirement changes agreed in comments ("AC updated:", "requirement:", "change request")
  for (const c of ticket.comments) {
    if (/\b(ac|acceptance criteria|requirement)s?\b.*\b(updated?|changed?|added?|new)\b/i.test(c.body) || /^\s*(AC|Requirement)\s*\d*\s*[:.-]/im.test(c.body)) {
      for (const t of collectItems(c.body)) if (AC_LABEL_RE.test(t) || CHECKBOX_RE.test(t) || /\b(must|should|shall|cannot|can't|only)\b/i.test(t)) push(t.replace(AC_LABEL_RE, "$2"), "comment");
    }
  }

  // Ids: author labels win; unlabeled items get the next free AC<n>.
  const used = new Set<string>();
  const requirements: Requirement[] = [];
  let counter = 0;
  for (const r of reqs) {
    let id = r.label && !used.has(r.label) ? r.label : "";
    while (!id || used.has(id)) id = `AC${++counter}`;
    used.add(id);
    requirements.push({ id, text: r.text, source: r.source, vague: r.vague });
  }

  const clarifications: string[] = [];
  if (requirements.length === 0) clarifications.push("The ticket has no identifiable acceptance criteria. Ask the author what 'done' looks like before testing.");
  for (const r of requirements) {
    if (r.vague.length) clarifications.push(`${r.id} uses vague wording (${r.vague.join(", ")}): "${r.text}". Ask for the observable, checkable outcome.`);
    if (/\b(etc|and more|and others|similar)\b/i.test(r.text)) clarifications.push(`${r.id} is open-ended ("etc."). Ask for the complete list.`);
  }
  if (ticket.type?.toLowerCase() === "bug" && !/steps to reproduce|repro/i.test(ticket.description)) clarifications.push("Bug ticket has no reproduction steps. Ask for them, or reconstruct from the description and confirm with the reporter.");
  if (ticket.pullRequests.length === 0) clarifications.push("No pull request is linked. Confirm the change is deployed to the target environment before testing (or ask for the PR).");

  return {
    ticket: { key: ticket.key, title: ticket.title, url: ticket.url, status: ticket.status, type: ticket.type, priority: ticket.priority, labels: ticket.labels, pullRequests: ticket.pullRequests },
    requirements,
    clarifications,
    outOfScope,
    preconditions,
    sections,
  };
}

/** Markdown rendering of an Analysis — written to test-cases/<KEY>/analysis.md */
export function renderAnalysis(a: Analysis, cfg: QaConfig): string {
  const lines: string[] = [];
  lines.push(`# ${a.ticket.key} — Requirement Analysis`, "");
  lines.push(`**Title:** ${a.ticket.title}  `);
  lines.push(`**Ticket:** ${a.ticket.url}  `);
  lines.push(`**Type / Status / Priority:** ${a.ticket.type ?? "—"} / ${a.ticket.status} / ${a.ticket.priority ?? "—"}  `);
  lines.push(`**Labels:** ${a.ticket.labels.join(", ") || "—"}  `);
  lines.push(`**Pull requests:** ${a.ticket.pullRequests.length ? a.ticket.pullRequests.join(", ") : "none linked"}`, "");
  lines.push("## Normalized acceptance criteria", "");
  lines.push("Each AC is one observable, checkable behaviour. The agent must map every AC to at least one test case.", "");
  if (a.requirements.length === 0) lines.push("_None found — see clarifications._");
  for (const r of a.requirements) lines.push(`- **${r.id}** ${r.text}${r.vague.length ? `  ⚠️ vague: ${r.vague.join(", ")}` : ""}  _(from: ${r.source})_`);
  lines.push("");
  if (a.preconditions.length) {
    lines.push("## Preconditions / test data", "");
    for (const p of a.preconditions) lines.push(`- ${p}`);
    lines.push("");
  }
  if (a.outOfScope.length) {
    lines.push("## Out of scope (do not test)", "");
    for (const p of a.outOfScope) lines.push(`- ${p}`);
    lines.push("");
  }
  lines.push("## Clarifications needed", "");
  if (a.clarifications.length === 0) lines.push("_None — requirements are testable as written._");
  for (const c of a.clarifications) lines.push(`- [ ] ${c}`);
  lines.push("");
  if (cfg.analysis.riskAreas.length) {
    lines.push("## Project risk areas to consider", "");
    for (const r of cfg.analysis.riskAreas) lines.push(`- ${r}`);
    lines.push("");
  }
  lines.push("## Ticket sections (raw)", "");
  for (const s of a.sections) {
    lines.push(`### ${s.heading || "(description)"}`, "", s.body || "_empty_", "");
  }
  return lines.join("\n");
}
