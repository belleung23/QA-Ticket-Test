# DEMO-42 — Manual Test Cases

Ticket: https://linear.app/example/issue/DEMO-42  
Environment: `dev` — (from qa.config.yaml)  
Analysis: ./analysis.md

## Preconditions / test data

- An Editor account with at least one saved filter named "Open bugs"
- A Viewer account with access to the same workspace

> Status vocabulary: Pass | Fail | Blocked | Skipped | — (not run).  
> Automate = yes marks a case approved for conversion to Playwright (`tqa scaffold`).  
> Column order is a contract — do not rename or reorder.

| # | AC | Priority | Type | Test Description | Test Steps | Expected Result | Actual Result | Status | Evidence | Automate |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | AC1, AC2 | High | Happy Path | Rename action appears on hover and opens inline edit | 1. Log in as Editor and open `/issues`<br>2. Hover "Open bugs" in the Saved filters sidebar<br>3. Click the "Rename" action | An inline text input replaces the name, pre-filled with "Open bugs", focused | Input appeared pre-filled and focused | Pass | test-reports/media/DEMO-42/TC1_pass_inline-edit.png | yes |
| 2 | AC3 | High | Happy Path | Enter saves the new name and it persists after reload | 1. From the inline input (TC1) clear and type "Open bugs — web"<br>2. Press Enter<br>3. Reload the page | Sidebar shows "Open bugs — web" immediately and after reload; PATCH /api/filters/:id returned 200 | Name updated; PATCH 200; still present after reload | Pass | test-reports/media/DEMO-42/TC2_pass_persist.png | yes |
| 3 | AC4 | Medium | Negative | Escape cancels the edit | 1. Open inline edit on a filter<br>2. Type "zzz"<br>3. Press Escape | Input closes, original name is shown, no network request sent | As expected; no PATCH in network log | Pass | test-reports/media/DEMO-42/TC3_pass_escape.png | yes |
| 4 | AC5 | High | Negative | Empty name is rejected | 1. Open inline edit<br>2. Clear the input<br>3. Press Enter | Validation message "Name is required" under the input; input stays open; no PATCH | Message shown, input stayed open, no PATCH | Pass | test-reports/media/DEMO-42/TC4_pass_required.png | yes |
| 5 | AC6 | Low | Edge Case | 60-character limit is enforced at input | 1. Open inline edit<br>2. Paste a 65-character string | Only the first 60 characters remain in the input | Input accepted 65 characters; saving sent 65 chars and the API returned 400 "name too long" with no UI message | Fail | test-reports/media/DEMO-42/TC5_fail_maxlength.png, TC5_fail.webm | yes |
| 6 | AC7 | High | Negative | Viewer cannot rename | 1. Log in as Viewer and open `/issues`<br>2. Hover "Open bugs" | No "Rename" action is shown; keyboard focus on the item offers no rename | No action shown | Pass | test-reports/media/DEMO-42/TC6_pass_viewer.png | yes |
| 7 | AC3 | Medium | Edge Case | Rename survives concurrent edit in a second tab | 1. Open two tabs as Editor<br>2. Rename in tab A to "A-name"<br>3. In tab B (not reloaded) rename to "B-name" | Last write wins: both tabs show "B-name" after reload; no error | Both tabs show "B-name" | Pass | — | no |
