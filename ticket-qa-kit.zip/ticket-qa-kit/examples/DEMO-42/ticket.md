# DEMO-42: Users can rename a saved filter

- URL: https://linear.app/example/issue/DEMO-42
- Type: Story · Status: In QA · Priority: High
- Labels: filters, web · Assignee: — · Reporter: —
- Pull requests: https://github.com/example/app/pull/318

## Description

As a user I want to rename a saved filter from the filters sidebar so that my filters stay meaningful.

## Acceptance Criteria

- [ ] Hovering a saved filter in the sidebar shows a "Rename" action
- [ ] Clicking Rename turns the name into an inline text input pre-filled with the current name
- [ ] Pressing Enter with a non-empty name saves it; the new name is shown in the sidebar and persists after reload
- [ ] Pressing Escape cancels and restores the old name
- [ ] An empty name shows the validation message "Name is required" and does not save
- [ ] Names are limited to 60 characters; the input refuses further typing at the limit
- [ ] Viewers (read-only role) do not see the Rename action

## Out of scope

- Renaming from the filter detail page (separate ticket DEMO-43)
