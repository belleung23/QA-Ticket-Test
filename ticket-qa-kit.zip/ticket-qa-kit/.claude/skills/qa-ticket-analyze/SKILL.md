---
name: qa-ticket-analyze
description: |
  Fetch a Linear or Jira ticket through the kit's tracker adapter, read its description, acceptance criteria, comments, linked tickets and pull requests, and turn them into a normalized, testable requirement list (analysis.md) plus a list of questions that must be answered before testing. Use whenever the user says "analyze <TICKET>", "what does <TICKET> require", "read the ticket", "what should I test for <TICKET>", or as step 1 of qa-ticket-pipeline.
allowed-tools:
  - Read
  - Write
  - Bash
  - Skill
---

# Analyze a ticket

Read `qa-shared-rules` first.

## Input

```text
/qa-ticket-analyze PROJ-123 [--env=<key>]
```

## Steps

1. **Fetch and auto-extract.**
   ```bash
   npm run tqa -- analyze <TICKET> [--env=<key>]
   ```
   This writes `test-cases/<TICKET>/ticket.md` (full ticket, markdown), `analysis.md` (auto-extracted AC list, preconditions, out-of-scope, clarifications) and a skeleton `manual.md` if none exists. If the tracker call fails, read the error: it names the missing `.env` value or the unknown key. Do not retry with guessed credentials.

2. **Read the whole ticket yourself**, not just the extracted list. Open `ticket.md`. The extractor is a regex pass; you are the reader. Look for:
   - requirements hidden in prose ("the button must be disabled until…"), in screenshots' captions, in comments that changed the scope ("let's drop X", "also handle Y")
   - linked tickets (parent, blockers, duplicates) whose behaviour this one depends on — fetch them with `npm run tqa -- fetch <KEY> --json` when the dependency matters
   - the pull request(s). If the harness has `gh`, read `gh pr view <url> --json title,state,mergedAt,files` and `gh pr diff <url>` to learn which routes/components changed. The diff tells you where the feature lives and what to look at; it does not replace the ticket as the source of truth.

3. **Rewrite `analysis.md`'s "Normalized acceptance criteria" section** so that every AC is one observable, checkable sentence. Split compound ACs ("saves and shows a toast" → two ACs). Keep the `AC<n>` ids stable once written — the manual table and the spec tags reference them. Add ACs you found in prose/comments/PR with `_(from: comment / prose / PR)_`.

4. **Clarifications.** For each item under "Clarifications needed", decide: can you resolve it from the ticket, linked tickets, or the running app? If yes, write the resolution and tick the box. If not, keep it open. If an open item blocks testing (no AC at all, contradictory requirements, the feature is not deployed), **stop here**, show the user the questions, and offer to post them on the ticket with `npm run tqa -- comment <TICKET> --file <path>`. Do not invent requirements to fill the gap.

5. **Scope map.** Add a short section "Where it lives" to `analysis.md`: the route(s)/screen(s), the roles that can reach them, data needed, and the project risk areas from the config that apply. This is what the test-case generator reads next.

## Output

`test-cases/<TICKET>/analysis.md` with: ticket summary, normalized AC list, preconditions, out of scope, resolved and open clarifications, where-it-lives. End your message with the AC count, the open-question count, and whether testing can start.
