---
name: qa-manual-run
description: |
  Execute the manual test cases in test-cases/<TICKET>/manual.md live: the agent drives a real browser against the environment from qa.config.yaml, performs each step, compares the outcome with the expected result, captures evidence, and fills in Actual Result / Status / Evidence. Use whenever the user says "run the manual tests for <TICKET>", "test <TICKET> on dev", "execute the test cases", "verify <TICKET> in the browser", or as step 3 of qa-ticket-pipeline.
allowed-tools:
  - Read
  - Write
  - Bash
  - Skill
---

# Manual run (agent drives the browser)

Read `qa-shared-rules` first.

Two ways a manual run happens in this kit — both write the same `manual.md`:

- **Agent-driven (this skill):** you perform the steps in a browser tool.
- **Recorded by a person (the local UI, `npm run ui` → Test cases → ● Record):** the tester clicks through by hand; the kit captures every action as steps + locators into `test-cases/<TICKET>/recordings/TC<n>.json`. When a row already has a recording, treat it as executed — do not redo it unless asked; use its steps as the authoritative procedure and its final screenshot as evidence.

When this skill is started from the UI ("Run with agent"), the command carries `--only <n,...>`: run exactly those rows and nothing else, and save `manual.md` after each row so the UI can refresh. Inputs: `test-cases/<TICKET>/manual.md` (must exist with rows), `--env=<key>` (optional), an optional case selection (`--only 1,4,7` / `--skip 3`).

## 1. Resolve the target — never from memory

```bash
npm run tqa -- config --env=<key>
```

Use the printed `environment.baseUrl`, `auth.strategy` and `paths.media`. If `environment.readOnly` is true, every row that modifies data becomes **Blocked** ("readOnly environment") before you start.

## 2. Pick the browser tool the harness gives you

In this order, use the first that exists; do not fall back silently to a different one once started:

1. `playwright-cli` (`bunx playwright-cli` / `npx playwright-cli`) — headless Chromium, isolated context
2. A Playwright MCP server (`browser_navigate`, `browser_snapshot`, `browser_click` …)
3. A Claude-in-Chrome / Chrome-automation tool
4. A Playwright script you write under `tmp/` and run with `npx tsx` (last resort)

Whichever tool: open a **fresh context**, load the saved session when `auth.strategy` is `storage-state` (`--storage-state .auth/<env>.storage-state.json` or the tool's equivalent), and navigate to `baseUrl`. If the first page is a login page and you have no session, stop and ask the user to run `npm run auth:save -- --env=<key>`.

## 3. Execute, one row at a time

For each selected row:

1. Read the steps. Perform them literally. If a step is impossible as written (element doesn't exist, route differs), that is a finding, not a reason to improvise: record what you saw, then try the obvious alternative **once**, and note the deviation in Actual Result.
2. After the last step, observe. Compare to Expected Result. Prefer the page's accessibility snapshot / text to screenshots for the comparison; use network responses (status + body) when the expected result is "saved"/"deleted"/"listed".
3. Check that the result survives a reload when the expected result is persistent state.
4. Capture evidence per the naming rule; write the relative path in **Evidence**.
5. Fill **Actual Result** (what actually happened, in one or two sentences, with the concrete value/text seen) and **Status**.
6. Clean up any data the row created.

Keep a running tally in the chat every few rows (`5/12 done — 4 Pass, 1 Fail`) so the user can follow.

## 4. When a row fails

Before writing Fail: reproduce it once more from a fresh page. If it reproduces, keep Fail and do a quick root-cause look: console errors, the failing network call (method, URL, status, response body), and — if the repo is at hand — the component or route from the PR diff. Put a one-paragraph "Likely cause" in Actual Result. If it does not reproduce, write `Pass` with the note "flaky on first attempt: <what happened>".

Do not stop the run at the first failure; finish the selected rows unless the environment is clearly down (then mark the rest Blocked with the reason).

## 5. Finish

- Save `manual.md` with all columns filled.
- Mark **Automate = yes** on rows that Passed, exercise stable UI, and are worth keeping as regression (main flows, permission gates, validation). Mark `no` on one-off exploratory rows or anything that depends on data you cannot seed. This column is the input to `qa-automate-from-manual`.
- Then run `qa-report-and-publish`.

## Session expiry

Symptoms: redirect to the login/SSO page, 401/403 on calls that worked a minute ago, an "oops / session not found" screen. Do: re-authenticate with the configured strategy, re-run the interrupted row only, continue. Say so in the report notes.
