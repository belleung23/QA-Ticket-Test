---
name: qa-shared-rules
description: |
  Shared rules for every ticket-qa-kit skill: where configuration comes from (qa.config.yaml + .env, never hardcoded), the result-status vocabulary, evidence naming, what makes an assertion real, and attribution rules for commits/PRs. Other skills say "Read qa-shared-rules first". Not a standalone workflow.
allowed-tools:
  - Read
  - Bash
---

# Shared rules (read first)

## 1. Nothing is hardcoded — the project is the config

- The app URL, environment list, login method, tracker, credentials and output folders all come from `qa.config.yaml` and `.env`. Run `npm run tqa -- config --env=<key>` to see the resolved, secret-free values. **Never** type a URL, username, password, token or team name into a skill, a spec, a comment or a report — read it from the config.
- If `qa.config.yaml` does not exist, stop and tell the user to run `npm run tqa -- init` and fill it in. Do not guess a project.
- Environment choice, in order: explicit `--env=<key>` → `QA_ENV` in `.env` → a hint in the ticket title (`environmentHints`, e.g. `[Prod]`) → `defaultEnvironment`. Reject an unknown key; never silently fall back.
- An environment with `readOnly: true` (usually prod) is observe-only: no creating, editing, deleting, uploading, or submitting. Mark such test cases **Blocked** there with the reason "readOnly environment", and run them on a writable environment instead.

## 2. Logging in

Strategy is `auth.strategy` in the config (per-environment override allowed):

| strategy | what the agent does |
|---|---|
| `none` | just open the base URL |
| `storage-state` | a human logged in once with `npm run auth:save -- --env=<key>`; reuse `.auth/<key>.storage-state.json`. If missing or expired, **ask the user to run that command** — do not try to log in through SSO yourself unless the user explicitly says to drive the SSO screens. |
| `form` | plain username/password page; selectors and `${APP_USERNAME}` / `${APP_PASSWORD}` come from the config |
| `script` | custom `login(page, ctx)` module at `auth.script.path` |

Session expired mid-run (redirect to login, 401s, "session not found")? Pause, re-authenticate with the same strategy, re-run only the test case that was interrupted, and note it in the report. Never mark a case Fail because the session expired.

## 3. Status vocabulary (exact spelling)

| Status | Meaning |
|---|---|
| `Pass` | every step done, actual result matches expected |
| `Fail` | a step or the outcome differs from expected — always with the actual result written out and evidence captured |
| `Blocked` | could not execute (env down, missing precondition, readOnly env, feature not deployed) — reason in Actual Result |
| `Skipped` | deliberately not run (out of scope, user excluded it) — reason in Actual Result |
| `—` | not run yet |

Verdict: any Fail → **FAILED**; any Blocked or `—` and no Fail → **INCOMPLETE**; all Pass/Skipped → **PASSED**.

## 4. Evidence

- Folder: `<paths.media>/<TICKET>/` (from config). Name files `TC<n>_<pass|fail>_<short-slug>.png`; recordings `TC<n>_fail.webm`.
- Every Fail gets a screenshot of the failing state and, when the tool can, a recording of the reproduction. Pass gets a screenshot of the final state.
- Put the relative path in the **Evidence** column. Never paste base64 into markdown.

## 5. What counts as a test

- One test case = one observable behaviour with numbered steps and an expected result a stranger could verify.
- Every acceptance criterion (AC) in `analysis.md` maps to at least one case. A case with no AC is either regression (type `Regression`) or should not exist.
- An automated test must contain an assertion that **can fail** if the feature regresses. `expect(true).toBe(true)`, asserting on an element you just created the locator for without navigating, or asserting only that no exception was thrown — none of these count. Lint (`npm run lint`) enforces `expect-expect`, `no-conditional-expect`, `no-wait-for-timeout`.
- No hardcoded waits (`waitForTimeout`). Use web-first assertions (`await expect(locator).toBeVisible()`), `waitForURL`, `waitForResponse`.
- Locator priority: `getByRole` → `getByLabel` / `getByPlaceholder` → `getByTestId` → `getByText` → CSS. Never XPath by position, never nth-child chains.
- A test must leave the system as it found it: data it created, it deletes (in `finally` / `afterEach`).

## 6. Writing things people will read

- Reports and ticket comments are for the team. Plain language, actual vs expected side by side, reproduction steps that start from a fresh page.
- The tester named in a report is the human who ran or supervised the run — never an AI tool name.
- Commits and PRs made from this kit carry **no AI co-author, "generated with", or session lines**. Branch name: `test/<ticket-key-lowercase>-<slug>` unless the project's own convention (check its CONTRIBUTING / existing branches) says otherwise. Commit message: `test(<TICKET>): <what the tests cover>` with a body listing the test cases.
- Keep one ticket per branch / PR; cap a PR at ~10–15 tests.

## 7. Before you say "done"

Run the four checks and show the output: `npm run typecheck`, `npm run lint`, `npx playwright test --list --grep <TICKET>` (collects the right number of tests), and the actual run. Green lint proves the code is tidy, not that it tests anything — re-read every assertion against the manual case it came from.
