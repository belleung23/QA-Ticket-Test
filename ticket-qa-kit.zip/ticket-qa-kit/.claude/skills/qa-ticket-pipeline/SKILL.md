---
name: qa-ticket-pipeline
description: |
  Top-level entry point of ticket-qa-kit. Given one Linear or Jira ticket key, runs the whole chain: analyze the ticket's requirements → write manual test cases → drive the browser to execute them on the configured environment → write the report (and optionally post it) → optionally promote the approved cases to Playwright TypeScript automation. Project-agnostic — everything comes from qa.config.yaml. Use whenever the user says "QA <TICKET>", "test <TICKET>", "verify <TICKET>", "run the pipeline on <TICKET>", "/qa-ticket-pipeline <TICKET>", or any request to test a ticket end to end.
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Skill
---

# Ticket QA pipeline

```text
/qa-ticket-pipeline PROJ-123
/qa-ticket-pipeline PROJ-123 --env=staging --mode=manual
/qa-ticket-pipeline PROJ-123 --mode=both --tester "Jane Doe"
```

Options: `--env=<key>` (from qa.config.yaml; default per config), `--mode=manual|automation|both` (default `manual`; `automation` requires an already-executed manual.md), `--tester "<name>"` (asked for if missing), `--only`/`--skip` case numbers, `--publish` (post the comment and transition without asking again).

Read `qa-shared-rules` first. Set `TICKET=<key>` and carry it through every step.

## Pre-flight

1. `npm run tqa -- config --env=<key>` — must succeed. If it fails, the message says which config/env value is missing; relay it and stop.
2. Confirm the environment is reachable (open `baseUrl`) and, for `storage-state`, that `.auth/<env>.storage-state.json` exists. If not: ask the user to run `npm run auth:save -- --env=<key>`.

## Chain

| step | skill | gate to continue |
|---|---|---|
| 1 | `qa-ticket-analyze` | ≥1 AC and no blocking open question |
| 2 | `qa-manual-test-cases` | every AC covered |
| 3 | `qa-manual-run` | every selected row has a Status |
| 4 | `qa-report-and-publish` | report written; publish only with consent |
| 5 (mode automation/both) | `qa-automate-from-manual` | typecheck + lint clean, 3 consecutive green runs |

Run them in order. Each step writes files under `test-cases/<TICKET>/`, `test-reports/`, `tests/<TICKET>/` so the pipeline can be resumed: if a file from an earlier step already exists and the user did not ask to redo it, reuse it and say so.

## The UI

`npm run ui` opens the same pipeline as pages at `http://localhost:<ui.port>`. People use it to review the analysis, edit the table, **record** a case by hand (steps + locators captured), start an agent run for selected rows, and generate the report/spec. Everything it does goes through the same files, so an agent and a person can alternate freely on one ticket.

## Stop conditions (say why, show what exists, ask)

- the ticket cannot be fetched (wrong key, tracker auth)
- the analysis finds no testable requirement or a contradiction
- the feature is not deployed on the chosen environment (PR not merged / 404 on the route)
- the session cannot be established

## Final message

Verdict and counts, open questions, links to `analysis.md`, `manual.md`, the report, the spec (if any), and what was posted to the tracker. Keep it to one screen.
