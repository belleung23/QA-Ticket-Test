---
name: qa-manual-test-cases
description: |
  Turn the normalized acceptance criteria in test-cases/<TICKET>/analysis.md into a complete manual test-case table (manual.md): happy path, negative and edge cases with numbered steps and expected results, every AC covered at least once. Use whenever the user says "generate test cases for <TICKET>", "write the test plan", "what cases should I run", or as step 2 of qa-ticket-pipeline.
allowed-tools:
  - Read
  - Write
  - Bash
---

# Manual test cases

Read `qa-shared-rules` first, then `test-cases/<TICKET>/analysis.md`. If analysis.md is missing, run `qa-ticket-analyze` first.

## The table is a contract

`manual.md` holds one Markdown table with exactly these columns, in this order:

```text
| # | AC | Priority | Type | Test Description | Test Steps | Expected Result | Actual Result | Status | Evidence | Automate |
```

Downstream tools parse it by header name (`npm run tqa -- report`, `npm run tqa -- scaffold`). Do not rename, reorder, or merge cells. Multi-line steps go in one cell separated by `<br>`; literal `|` is written `\|`.

## Rules

- Every `AC<n>` from analysis.md appears in at least one row's **AC** column. A row may cover several (`AC1, AC3`).
- Mix of types: `Happy Path` (the AC as written), `Negative` (invalid input, missing permission, wrong state — what should be refused and how), `Edge Case` (boundaries, empty/max, double-submit, refresh mid-flow, slow network, concurrent change). Add `Regression` rows only for behaviour the change could plausibly break, and say why in the description.
- Steps start from a known state ("Open `<baseUrl>/settings` as <role>") and are numbered. Someone who has never seen the feature must be able to follow them.
- Expected Result is observable: what is on screen, what the URL is, what the API returned, what is in the list after reload. "Works correctly" is not an expected result.
- Priority: `High` = main flow or release-blocking; `Medium` = secondary behaviour; `Low` = cosmetic/edge.
- Preconditions and test data go in a short section above the table, not in every row.
- Cases that create/modify data: say so in the description ("creates a policy") so the readOnly rule can apply.
- Leave **Actual Result**, **Status**, **Evidence** as `—` and **Automate** as `—`. They are filled during execution and review.
- Sanity limits: if you are past ~25 rows, the ticket is probably several features — say so and split by AC group rather than padding.

## Output

Rewrite `test-cases/<TICKET>/manual.md` (keep the header block the CLI generated). End with a coverage line: `N test cases covering AC1–ACk; uncovered: none` — if anything is uncovered, fix it before finishing.
