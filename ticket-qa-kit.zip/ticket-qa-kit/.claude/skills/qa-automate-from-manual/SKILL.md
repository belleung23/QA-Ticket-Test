---
name: qa-automate-from-manual
description: |
  Convert the manual test cases marked Automate = yes in test-cases/<TICKET>/manual.md into Playwright TypeScript specs under tests/<TICKET>/, implement real locators and falsifiable assertions, run them against the configured environment until they pass three times in a row, and gate with typecheck + lint. Automation is always derived from executed manual cases — never written from the ticket directly. Use whenever the user says "automate <TICKET>", "write playwright tests for <TICKET>", "convert the manual cases", "regression tests for <TICKET>", or as step 4 of qa-ticket-pipeline.
allowed-tools:
  - Read
  - Write
  - Edit
  - Bash
  - Skill
---

# Automate from manual cases

Read `qa-shared-rules` first. Precondition: `manual.md` has rows with **Automate = yes** that were actually run (Status is Pass, or Fail with a filed bug the test should catch). If no row is marked, ask the user which cases to promote; do not promote everything by default.

## 1. Scaffold

```bash
npm run tqa -- scaffold <TICKET>        # → tests/<TICKET>/<slug>.spec.ts
```

Rows that were **recorded** in the UI (`test-cases/<TICKET>/recordings/TC<n>.json`) come out with real actions already in place — `page.getByRole(...)`, `fill`, `toHaveURL` after navigations — instead of TODOs; only the final expectation and any "Verify:" notes remain to implement. Still read every recorded line: a recorder picks the locator that was unique at that moment, not necessarily the most stable one.

The skeleton mirrors each approved row 1:1: one `test()` per case, titled `TC<n> <description> @<TICKET> @TC<n> @<Priority> @<type> @regression`, one `test.step` per manual step, a final step for the expected result, and `assertWritable(env, envKey)` on cases that modify data. Keep that structure — it is what makes the spec traceable back to the manual case and the AC.

## 2. Implement every TODO

- Fixtures come from `src/fixtures/test.ts`: `page` is authenticated per config, `env.baseUrl` is the target, `envKey` names it. Never put a URL, account, or token in a spec. Routes are relative: `page.goto("/settings")`.
- Learn the real locators from the live page (open it with the same browser tool as the manual run and read the accessibility tree) or from the app's source if the repo is at hand. Follow the locator priority in the shared rules.
- The final `test.step` must assert the **observable outcome** from the manual row's Expected Result, and it must be able to fail. Prefer: `toHaveURL`, `toBeVisible`/`toBeHidden` on the result element, `toHaveText`/`toContainText` with the exact text, `toHaveCount`, a `waitForResponse` whose status/body you assert, state after `page.reload()` for persistence.
- Test data: generate unique values per run (`${Date.now()}` suffix) and delete them in `finally`. Put shared helpers in `tests/<TICKET>/helpers.ts` or, when reused across tickets, `tests/_shared/`. Page-object style is welcome when ≥2 specs touch the same screen; one class per screen, methods named after user actions.
- Negative cases assert the refusal (error text, disabled control, 4xx response), not merely "nothing crashed".
- No `waitForTimeout`, no `test.only`, no `try/catch` that swallows an assertion.

## 3. Run until stable

```bash
npm run typecheck
npm run lint
npx playwright test --list --grep <TICKET>      # expect: number of Automate=yes rows
npm run tqa -- run <TICKET> --env=<key>
```

Fix failures by reading the trace (`npx playwright show-trace test-results/**/trace.zip`) — fix the locator or the wait, never weaken the assertion. When green, run the ticket's specs **three more times**; all three must pass. A test that fails once in three is not done: find the race (usually a missing web-first wait or shared data) and fix it.

If a test fails because the app is genuinely broken (the manual run also found it), keep the assertion correct, mark the test with `test.fixme("<BUG-KEY>: <why>")`, and say so in the report — do not change the expected result to match the bug.

## 4. Hand-off

Update `manual.md`: for each automated row, append the spec path to the Evidence cell (`tests/<TICKET>/x.spec.ts#TC3`). Then, if the user wants it committed: branch `test/<ticket>-<slug>`, commit `test(<TICKET>): <coverage>`, no AI attribution lines, ≤15 tests per PR, PR description listing TC numbers ↔ ACs and the three-run evidence. Ask before pushing.
