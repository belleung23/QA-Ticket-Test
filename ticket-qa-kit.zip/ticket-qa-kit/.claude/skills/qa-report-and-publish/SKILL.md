---
name: qa-report-and-publish
description: |
  Build the QA report from test-cases/<TICKET>/manual.md (verdict, AC coverage, failures with repro steps), write it to test-reports/, and — only when the user authorizes it — post the summary comment on the Linear/Jira ticket and move it to the configured status. Use whenever the user says "write the report for <TICKET>", "post results", "comment on the ticket", "mark <TICKET> passed/failed", or as the last step of qa-ticket-pipeline.
allowed-tools:
  - Read
  - Write
  - Bash
---

# Report and publish

Read `qa-shared-rules` first.

## 1. Report

```bash
npm run tqa -- report <TICKET> --tester "<human name>" [--env=<key>] [--mode manual|automation] [--note "..."]
```

Writes `test-reports/<TICKET>_<PASSED|FAILED|INCOMPLETE>_<date>.md` and `test-cases/<TICKET>/comment.md` (the short version for the ticket). `--tester` is the person who ran or supervised the run — ask if you don't know; never put an AI tool's name there.

Open the report and check it reads well: the AC coverage table has no `⚠️ uncovered` rows, every Fail has actual vs expected and reproduction steps, notes mention session recoveries, flaky observations, environment problems and any `test.fixme`. Edit the markdown by hand if the generated text needs context.

## 2. Bugs

For each Fail that is a product defect (not a test or environment problem), draft a bug: title `[<area>] <what is wrong> when <condition>`, environment + build/PR, steps, expected, actual, evidence path, likely cause. Show the drafts to the user. File them only if the user says so (with the tracker's own tooling or the project's bug-filing skill if one exists), then add them under "Bugs filed" in the report and the comment.

## 3. Publish — ask first

Posting to the tracker is visible to the whole team. Ask the user once: "Post the comment on <TICKET> and move it to <status>?" Then:

```bash
npm run tqa -- comment <TICKET>                  # posts test-cases/<TICKET>/comment.md
npm run tqa -- status <TICKET>                   # lists states/transitions available right now
npm run tqa -- status <TICKET> "<state name>"    # e.g. the config's readyToRelease / failedQa name
```

PASSED → the config's `readyToRelease` state. FAILED → `failedQa` (or whatever the project uses) with the bug keys in the comment. INCOMPLETE → comment only, no transition, say what is still open.

If posting fails (permissions, unknown state), report the error verbatim and leave the local report as the deliverable — results are not lost because publication failed.

## 4. Tell the user

One short paragraph: verdict, pass/fail counts, where the report is, what was posted, what needs a human decision.
