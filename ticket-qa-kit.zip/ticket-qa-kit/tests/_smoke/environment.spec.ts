import { test, expect } from "../../src/fixtures/test.js";

/**
 * Environment smoke test — proves the configured environment is reachable and
 * the session (if any) is valid before a ticket's specs run. Tagged @smoke so it
 * can be run alone: npx playwright test --grep @smoke
 */
test("configured environment responds and is not a login page @smoke", async ({ page, env, envKey, qa }) => {
  const response = await page.goto("/");
  expect(response, `no response from ${env.baseUrl}`).not.toBeNull();
  expect(response!.status(), `${envKey} returned HTTP ${response!.status()}`).toBeLessThan(400);
  await expect(page).toHaveTitle(/.+/);
  if (qa.auth.strategy !== "none") {
    // A bounced-to-login URL means the saved session expired: re-run `npm run auth:save`.
    await expect(page, "redirected to a login/SSO page — session invalid").not.toHaveURL(/login|signin|sso|auth/i);
  }
});
