# AGENTS.md — how any coding agent should work in this repo

This file is read by Codex, Cursor, OpenCode and similar agents. Claude Code reads
`CLAUDE.md`, which points here. The detailed procedures live in `.claude/skills/*/SKILL.md`
and are plain Markdown — **read them even if your harness does not have a "skills" feature.**

## What this repo is

A project-agnostic QA kit. Given a Linear or Jira ticket key it:

1. fetches the ticket and turns its description/AC/comments/PRs into a testable requirement list,
2. writes manual test cases (happy / negative / edge, every AC covered),
3. **drives a real browser** to execute them on the configured environment and records results,
4. writes a report and (with consent) posts it back on the ticket,
5. promotes the approved manual cases into **Playwright + TypeScript** specs and runs them until stable.

Nothing about a specific product is in the code. The product is `qa.config.yaml` + `.env`.

## Golden rules

- **Never hardcode** a URL, account, password, token, team name or environment. Read them with
  `npm run tqa -- config --env=<key>`. If the config is missing, tell the user to run
  `npm run tqa -- init`; do not guess.
- **Automation comes from executed manual cases**, never straight from the ticket. The flow is
  always analyze → manual cases → manual run → report → (then) automation.
- **Every automated test must be able to fail.** See `.claude/skills/qa-shared-rules/SKILL.md` §5.
- `readOnly: true` environments are observe-only.
- Reports name a human tester. Commits/PRs carry **no AI attribution lines**.
- Ask before anything visible to the team: posting comments, changing ticket status, pushing.

## Entry points

| you want to… | do |
|---|---|
| run everything for a ticket | follow `.claude/skills/qa-ticket-pipeline/SKILL.md` |
| only understand the ticket | `.claude/skills/qa-ticket-analyze/SKILL.md` |
| only write the manual cases | `.claude/skills/qa-manual-test-cases/SKILL.md` |
| execute them in a browser | `.claude/skills/qa-manual-run/SKILL.md` |
| write the report / post it | `.claude/skills/qa-report-and-publish/SKILL.md` |
| turn approved cases into Playwright | `.claude/skills/qa-automate-from-manual/SKILL.md` |

## The local UI (people) and you (agent) share the same files

`npm run ui` serves a web page where a tester can record a test case by hand (the kit
captures clicks/fills/navigations as steps **and** Playwright locators into
`test-cases/<KEY>/recordings/TC<n>.json`), mark results, and press "Run with agent" — which
launches `ui.agentCommand` from `qa.config.yaml` with `/qa-manual-run <KEY> --only <n>` (or shows
the command to paste). Honour `--only`, save `manual.md` after every row, and never redo a row that
already has a recording unless asked.

## CLI you will use

```bash
npm run tqa -- init                       # create qa.config.yaml + .env from examples
npm run tqa -- config [--env=dev]         # validate + print resolved, secret-free config
npm run tqa -- fetch  PROJ-1 [--json]     # ticket → test-cases/PROJ-1/ticket.{json,md}
npm run tqa -- analyze PROJ-1             # → analysis.md + skeleton manual.md
npm run tqa -- scaffold PROJ-1            # manual.md (Automate=yes) → tests/PROJ-1/*.spec.ts
npm run tqa -- report PROJ-1 --tester "Name"
npm run tqa -- comment PROJ-1             # post test-cases/PROJ-1/comment.md to the ticket
npm run tqa -- status PROJ-1 ["State"]    # list / transition
npm run auth:save -- --env=dev            # human logs in once; session saved to .auth/
npm run tqa -- run PROJ-1 [--env=dev] [--headed]
npm run ui                                # local web UI on http://localhost:4321
npm run typecheck && npm run lint
```

## Layout

```
qa.config.yaml          the project (committed, no secrets)   .env  secrets (ignored)
src/config              load + validate config, env interpolation, environment resolution
src/trackers            Linear (GraphQL) and Jira (REST, ADF↔markdown) behind one Ticket model
src/analyze             requirement extraction; manual → spec scaffolder
src/auth                login strategies: none | form | storage-state | script; global setup
src/fixtures/test.ts    the `test`/`expect` specs import — authenticated page, env, readOnly guard
src/report              manual.md table parser/renderer, report + ticket-comment renderers
src/pipeline.ts         the steps as functions (Kit) — used by the CLI and the UI server
src/recorder            in-page action recorder (inject.ts), codegen to steps + Playwright, session
src/ui                  zero-dependency local web server + single-page app
test-cases/<KEY>/       ticket.md, analysis.md, manual.md, comment.md
test-reports/           <KEY>_<VERDICT>_<date>.md and media/
tests/<KEY>/            generated + implemented Playwright specs
.claude/skills/         the procedures (read them)
```
