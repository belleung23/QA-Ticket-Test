# ticket-qa-kit

Give it a ticket key. It reads the ticket from **Linear or Jira**, works out what the requirements
actually are, writes manual test cases, has an AI agent **drive a real browser** to execute them on
your environment, writes the report back to the ticket, and — once the manual cases are proven —
turns them into **Playwright + TypeScript** regression tests.

It works for any web project: the product, the environments, the login method, the tracker and the
credentials are all configuration. Nothing is hardcoded.

```
ticket ──▶ analysis.md ──▶ manual.md ──▶ agent runs it in a browser ──▶ report + ticket comment
                                              │
                                              └──▶ approved rows ──▶ tests/<KEY>/*.spec.ts (Playwright)
```

## Requirements

- Node 20+
- A Linear API key **or** a Jira email + API token (Cloud) / personal access token (Server/DC)
- An AI coding agent that can drive a browser: Claude Code / Cowork (with `playwright-cli`, a
  Playwright MCP, or Claude in Chrome), Codex, Cursor, OpenCode… The agent reads `AGENTS.md` and
  the skills in `.claude/skills/`. The CLI also works without any agent.

## Setup (5 minutes)

```bash
git clone <this repo> && cd ticket-qa-kit
npm install
npx playwright install chromium        # or firefox / webkit, matching qa.config.yaml

npm run tqa -- init                    # creates qa.config.yaml and .env from the examples
```

Edit **`qa.config.yaml`** — the project. Minimum:

```yaml
project:  { name: My Product, ticketPattern: "^PROJ-\\d+$" }
tracker:  { kind: linear }            # or jira
environments:
  dev:     { baseUrl: https://app.dev.example.com }
  prod:    { baseUrl: https://app.example.com, readOnly: true }
defaultEnvironment: dev
auth:     { strategy: storage-state }  # none | form | storage-state | script
```

Edit **`.env`** — the secrets (git-ignored): `LINEAR_API_KEY` or `JIRA_BASE_URL` / `JIRA_EMAIL` /
`JIRA_API_TOKEN`, plus `APP_USERNAME` / `APP_PASSWORD` if you use the `form` strategy.

Check it:

```bash
npm run tqa -- config                  # validates and prints the resolved config, secrets masked
npm run tqa -- fetch PROJ-123 --json   # proves the tracker connection
```

### Logging in

| your app uses… | set `auth.strategy` to | and |
|---|---|---|
| no login | `none` | — |
| a username/password form | `form` | put the three selectors in `auth.form`, creds in `.env` |
| SSO / Google / Okta / MFA | `storage-state` | run `npm run auth:save -- --env=dev`, log in by hand once, press Enter. The session is saved to `.auth/dev.storage-state.json` (git-ignored) and reused by the agent and by Playwright until it expires. |
| something custom (token injection, bootstrap endpoint…) | `script` | write `auth/custom-login.ts` exporting `login(page, ctx)` |

## The web UI

```bash
npm run ui          # → http://localhost:4321  (port: ui.port in qa.config.yaml)
```

Type a ticket key, press **Open**: the ticket is fetched, the requirements extracted and a test-case
table created. Then, per test case:

| button | what happens |
|---|---|
| **● Record** | A logged-in browser opens on your environment. You do the test by hand. Every click, fill, checkbox, select, key press and navigation is captured as a readable step *and* as the Playwright locator (`getByRole`, `getByLabel`, `getByTestId`, …). Type what you verified ("toast says Saved") into *Add verification*. **Stop & use steps** writes the steps into the row, attaches the screenshots as evidence, asks Pass/Fail, and saves `recordings/TC<n>.json`. |
| **▶ Run with agent** | Starts `ui.agentCommand` with `/qa-manual-run KEY --only n` (e.g. `claude -p "{prompt}"`), or shows the command to paste into Claude/Codex/Cursor. The table refreshes as the agent writes results. |

Tabs: **Analysis** (the AC list and open questions), **Report** (generate, post the comment, move the
ticket — each asks first), **Automation** (generate the spec; recorded rows get real code, the rest
TODOs), **Ticket** (the raw ticket).

The UI holds no state of its own — it reads and writes the same `test-cases/`, `test-reports/` and
`tests/` files the CLI and the agent skills use, so a person and an agent can take turns on one ticket.

## Using it with an agent

In Claude Code / Cowork:

```text
/qa-ticket-pipeline PROJ-123
/qa-ticket-pipeline PROJ-123 --env=staging --mode=both --tester "Your Name"
```

In Codex / Cursor / anything that reads `AGENTS.md`: "QA PROJ-123 following AGENTS.md".

What happens, step by step (each is also its own skill you can run alone):

| step | skill | produces |
|---|---|---|
| 1 Analyze | `qa-ticket-analyze` | `test-cases/PROJ-123/analysis.md` — normalized AC list, preconditions, out-of-scope, **questions to ask before testing** |
| 2 Cases | `qa-manual-test-cases` | `test-cases/PROJ-123/manual.md` — happy / negative / edge rows, every AC covered |
| 3 Run | `qa-manual-run` | the agent opens the app, performs every step, compares with the expected result, captures evidence, fills Actual Result / Status |
| 4 Report | `qa-report-and-publish` | `test-reports/PROJ-123_PASSED_2026-10-15.md` + a comment on the ticket + status transition (asks first) |
| 5 Automate | `qa-automate-from-manual` | `tests/PROJ-123/*.spec.ts` from the rows you marked **Automate = yes**, implemented, run 3× green |

Why manual first, automation second: a test written straight from a ticket encodes the author's
guess about the UI. A test written from a manual case that a person (or agent) actually executed
encodes what the UI really does — the locators are known, the expected result was observed, and the
row's `Automate` flag is a human decision about what is worth keeping as regression.

## Using the CLI without an agent

```bash
npm run tqa -- analyze PROJ-123          # fetch + extract AC + skeleton manual.md
#   …fill manual.md by hand, run it by hand, fill Actual/Status/Evidence…
npm run tqa -- report PROJ-123 --tester "Your Name"
npm run tqa -- comment PROJ-123          # post comment.md to the ticket
npm run tqa -- status PROJ-123 "Ready To Release"
npm run tqa -- scaffold PROJ-123         # Automate=yes rows → spec skeleton
npm run tqa -- run PROJ-123 --headed     # run the specs on the configured env
npm run selftest                         # unit tests (parsers, analyzer, codegen)
npm run selftest:recorder                # headless end-to-end test of the recorder
```

## The manual.md contract

One table, these columns, this order — the CLI and the skills parse it by name:

```
| # | AC | Priority | Type | Test Description | Test Steps | Expected Result | Actual Result | Status | Evidence | Automate |
```

Status ∈ `Pass | Fail | Blocked | Skipped | —`. Automate ∈ `yes | no | —`.
See `templates/manual-test-cases.md` and `examples/` for a filled one.

## Writing specs

```ts
import { test, expect, assertWritable } from "../../src/fixtures/test.js";

test("TC3 user can rename a policy @PROJ-123 @TC3 @High @happy-path @regression", async ({ page, env, envKey }) => {
  assertWritable(env, envKey);                       // refuses to run on readOnly envs
  await page.goto("/policies");                      // relative to env.baseUrl
  await page.getByRole("link", { name: "Default" }).click();
  await page.getByLabel("Name").fill(`Renamed ${Date.now()}`);
  await page.getByRole("button", { name: "Save" }).click();
  await expect(page.getByRole("status")).toHaveText(/saved/i);   // can fail → real test
});
```

`page` is already logged in (per `auth.strategy`), `baseURL` is the environment, traces/videos are
kept on failure. `npm run lint` fails a spec that has no assertion, a conditional assertion, or a
`waitForTimeout`.

## Adapting to your team

- **Ticket format**: `project.ticketPattern`, `analysis.requirementHeadings` (which headings hold
  the AC), `analysis.vagueWords` (what gets flagged for clarification), Jira
  `acceptanceCriteriaField` if your AC lives in a custom field.
- **Workflow names**: `tracker.linear.states` / `tracker.jira.transitions`.
- **Risk areas**: `analysis.riskAreas` — things the agent should always consider for your product
  (permissions, i18n, audit logs…).
- **Where files go**: `paths.*`.
- **Procedures**: edit the Markdown in `.claude/skills/`. They are deliberately plain prose.

## Security notes

`.env`, `.auth/` and storage-state files are git-ignored; `npm run tqa -- config` masks secrets.
The kit talks only to your tracker's API and your app. Prod-like environments should be
`readOnly: true` so the agent never writes there.

## License

MIT
